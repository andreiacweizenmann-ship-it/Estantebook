# Regras de ofuscação (o APK de depuração não usa ofuscação).
-dontwarn org.slf4j.**
