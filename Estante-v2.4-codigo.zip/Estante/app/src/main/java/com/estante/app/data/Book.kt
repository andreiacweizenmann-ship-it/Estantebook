package com.estante.app.data

import org.json.JSONArray
import org.json.JSONObject

enum class BookFormat { PDF, COMIC, EPUB }

data class Book(
    val id: String,
    val title: String,
    val author: String = "",
    val collection: String = "",
    val studio: String = "",
    val format: BookFormat = BookFormat.PDF,
    val fileName: String,
    val coverFileName: String? = null,
    val pageCount: Int = 0,
    val lastPage: Int = 0,
    /** Fração do livro já lida (0..1). Zero = ainda não iniciado. */
    val progress: Float = 0f,
    val rating: Int = 0,
    val read: Boolean = false,
    val addedAt: Long = System.currentTimeMillis(),
    val lastReadAt: Long = 0L,
) {
    /** Progresso de leitura de 0 a 1, usado na barrinha da capa e nas telas de leitura. */
    fun progressFraction(): Float = when {
        read -> 1f
        progress > 0f -> progress.coerceIn(0f, 1f)
        lastPage > 0 && pageCount > 0 -> ((lastPage + 1f) / pageCount).coerceIn(0f, 1f)
        else -> 0f
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("title", title)
        put("author", author)
        put("collection", collection)
        put("studio", studio)
        put("format", format.name)
        put("file", fileName)
        put("cover", coverFileName ?: "")
        put("pageCount", pageCount)
        put("lastPage", lastPage)
        put("progress", progress.toDouble())
        put("rating", rating)
        put("read", read)
        put("addedAt", addedAt)
        put("lastReadAt", lastReadAt)
    }

    companion object {
        fun fromJson(o: JSONObject): Book = Book(
            id = o.getString("id"),
            title = o.optString("title"),
            author = o.optString("author"),
            collection = o.optString("collection"),
            studio = o.optString("studio"),
            format = runCatching { BookFormat.valueOf(o.optString("format")) }
                .getOrDefault(BookFormat.PDF),
            fileName = o.getString("file"),
            coverFileName = o.optString("cover").ifEmpty { null },
            pageCount = o.optInt("pageCount"),
            lastPage = o.optInt("lastPage"),
            progress = o.optDouble("progress", 0.0).toFloat(),
            rating = o.optInt("rating"),
            read = o.optBoolean("read"),
            addedAt = o.optLong("addedAt"),
            lastReadAt = o.optLong("lastReadAt"),
        )
    }
}

/** Grupo personalizado de livros (tema, série, "para ler nas férias"...). A ordem da lista é a ordem na prateleira. */
data class BookGroup(
    val id: String,
    val name: String,
    val bookIds: List<String> = emptyList(),
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        val arr = JSONArray()
        bookIds.forEach { arr.put(it) }
        put("books", arr)
    }

    companion object {
        fun fromJson(o: JSONObject): BookGroup {
            val arr = o.optJSONArray("books")
            val ids = if (arr == null) emptyList() else List(arr.length()) { arr.getString(it) }
            return BookGroup(
                id = o.getString("id"),
                name = o.optString("name").ifBlank { "Grupo" },
                bookIds = ids,
            )
        }
    }
}
