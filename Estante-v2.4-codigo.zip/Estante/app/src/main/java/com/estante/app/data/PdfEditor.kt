package com.estante.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.ExifInterface
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.contentstream.operator.Operator
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdfparser.PDFStreamParser
import com.tom_roush.pdfbox.pdfwriter.ContentStreamWriter
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.common.PDStream
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------------------------
// Modelo da edição
// ---------------------------------------------------------------------------------------------

/** De onde vem uma página do PDF em edição. */
sealed interface PageRef

/** Página [page] do PDF de índice [source] (0 = o livro original, 1+ = PDFs juntados). */
data class PdfPageRef(val source: Int, val page: Int) : PageRef

/** Imagem adicionada pelo usuário (já copiada para o cache); vira uma página inteira. */
data class ImagePageRef(val file: File) : PageRef

data class EditPage(
    val id: Long,
    val ref: PageRef,
    /** Melhorar a qualidade da imagem desta página. */
    val enhance: Boolean = false,
    /** Remover as imagens que estão dentro desta página (só PDF). */
    val stripImages: Boolean = false,
)

enum class EnhanceLevel(
    val label: String,
    /** Força do realce de nitidez. */
    val sharpen: Float,
    /** Fração de pixels nas pontas do histograma que é ignorada ao esticar o contraste. */
    val clip: Float,
    /** 1 = cores originais. */
    val saturation: Float,
) {
    LIGHT("Leve", 0.5f, 0.003f, 1.00f),
    NORMAL("Normal", 0.9f, 0.01f, 1.06f),
    STRONG("Forte", 1.5f, 0.02f, 1.14f),
}

// ---------------------------------------------------------------------------------------------
// Melhoria de imagem
// ---------------------------------------------------------------------------------------------

/**
 * Melhora uma imagem em três passos:
 *  1. imagens pequenas são ampliadas (até 2x);
 *  2. o contraste é esticado automaticamente (níveis automáticos);
 *  3. máscara de nitidez (unsharp mask) só na luminosidade, para não criar bordas coloridas,
 *     mais um leve ajuste de saturação.
 * Devolve um bitmap novo; o original não é alterado.
 */
object ImageEnhancer {

    fun enhance(src: Bitmap, level: EnhanceLevel): Bitmap {
        var input = src
        val longest = max(src.width, src.height)
        if (longest < 1800) {
            val scale = min(2f, 3200f / longest)
            if (scale > 1.05f) {
                input = Bitmap.createScaledBitmap(
                    src,
                    (src.width * scale).roundToInt(),
                    (src.height * scale).roundToInt(),
                    true,
                )
            }
        }
        val w = input.width
        val h = input.height
        val n = w * h
        val px = IntArray(n)
        input.getPixels(px, 0, w, 0, 0, w, h)
        if (input !== src) input.recycle()

        // 1) níveis automáticos
        val hist = IntArray(256)
        for (p in px) hist[luma(p)]++
        val clipCount = (n * level.clip).toInt()
        var lo = 0
        var acc = 0
        while (lo < 254) {
            acc += hist[lo]
            if (acc > clipCount) break
            lo++
        }
        var hi = 255
        acc = 0
        while (hi > lo + 1) {
            acc += hist[hi]
            if (acc > clipCount) break
            hi--
        }
        val lut = IntArray(256) { it }
        if (hi - lo >= 40) {
            for (v in 0..255) {
                lut[v] = ((v - lo) * 255f / (hi - lo)).roundToInt().coerceIn(0, 255)
            }
        }

        val lumaMap = ByteArray(n)
        for (i in 0 until n) {
            val p = px[i]
            val r = lut[(p shr 16) and 0xFF]
            val g = lut[(p shr 8) and 0xFF]
            val b = lut[p and 0xFF]
            val q = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            px[i] = q
            lumaMap[i] = luma(q).toByte()
        }

        // 2) desfoque da luminosidade (2 passadas de caixa ≈ gaussiano)
        val radius = max(1, max(w, h) / 900)
        val tmp = ByteArray(n)
        val blur = ByteArray(n)
        blurHorizontal(lumaMap, tmp, w, h, radius)
        blurVertical(tmp, blur, w, h, radius)
        blurHorizontal(blur, tmp, w, h, radius)
        blurVertical(tmp, blur, w, h, radius)

        // 3) nitidez + saturação
        val amount = level.sharpen
        val sat = level.saturation
        for (i in 0 until n) {
            val p = px[i]
            val y = lumaMap[i].toInt() and 0xFF
            var diff = y - (blur[i].toInt() and 0xFF)
            if (abs(diff) < 2) diff = 0 // não realça ruído fraco
            val d = diff * amount
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            val nr = (y + (r - y) * sat + d).roundToInt().coerceIn(0, 255)
            val ng = (y + (g - y) * sat + d).roundToInt().coerceIn(0, 255)
            val nb = (y + (b - y) * sat + d).roundToInt().coerceIn(0, 255)
            px[i] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
        }

        val result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        result.setPixels(px, 0, w, 0, 0, w, h)
        return result
    }

    private fun luma(p: Int): Int =
        ((((p shr 16) and 0xFF) * 77) + (((p shr 8) and 0xFF) * 151) + ((p and 0xFF) * 28)) shr 8

    private fun blurHorizontal(src: ByteArray, dst: ByteArray, w: Int, h: Int, r: Int) {
        val size = 2 * r + 1
        for (y in 0 until h) {
            val row = y * w
            var sum = 0
            for (i in -r..r) sum += src[row + i.coerceIn(0, w - 1)].toInt() and 0xFF
            for (x in 0 until w) {
                dst[row + x] = (sum / size).toByte()
                val add = src[row + min(x + r + 1, w - 1)].toInt() and 0xFF
                val sub = src[row + max(x - r, 0)].toInt() and 0xFF
                sum += add - sub
            }
        }
    }

    private fun blurVertical(src: ByteArray, dst: ByteArray, w: Int, h: Int, r: Int) {
        val size = 2 * r + 1
        for (x in 0 until w) {
            var sum = 0
            for (i in -r..r) sum += src[i.coerceIn(0, h - 1) * w + x].toInt() and 0xFF
            for (y in 0 until h) {
                dst[y * w + x] = (sum / size).toByte()
                val add = src[min(y + r + 1, h - 1) * w + x].toInt() and 0xFF
                val sub = src[max(y - r, 0) * w + x].toInt() and 0xFF
                sum += add - sub
            }
        }
    }
}

/** Carrega uma imagem do cache já na orientação certa (fotos de celular vêm com rotação no EXIF). */
fun loadImageFile(file: File, targetWidth: Int): Bitmap? {
    val bitmap = runCatching { decodeSampled(targetWidth) { file.inputStream() } }.getOrNull()
        ?: return null
    val orientation = runCatching {
        ExifInterface(file.absolutePath)
            .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
    }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
    val matrix = Matrix()
    when (orientation) {
        ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
        ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
        ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
        ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
        ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
        else -> return bitmap
    }
    val rotated = runCatching {
        Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }.getOrNull() ?: return bitmap
    if (rotated !== bitmap) bitmap.recycle()
    return rotated
}

// ---------------------------------------------------------------------------------------------
// Geração do PDF final
// ---------------------------------------------------------------------------------------------

class PdfEditor(context: Context) {
    private val appContext = context.applicationContext

    init {
        PDFBoxResourceLoader.init(appContext)
    }

    /** Capa (primeira página) de um PDF já pronto. */
    suspend fun cover(file: File): Bitmap? = runCatching {
        val source = PdfPageSource(file)
        try {
            source.render(0, 600)
        } finally {
            source.close()
        }
    }.getOrNull()

    /**
     * Monta o PDF final em [output], na ordem de [pages].
     *  - página de PDF sem melhoria: copiada como está (texto, vetores e tamanho preservados);
     *  - página de PDF com melhoria: desenhada em alta resolução, melhorada e inserida como imagem;
     *  - imagem do usuário: vira uma página (melhorada, se marcada).
     * [onProgress] recebe (páginas prontas, total).
     */
    suspend fun build(
        sources: List<File>,
        pages: List<EditPage>,
        level: EnhanceLevel,
        output: File,
        onProgress: (Int, Int) -> Unit,
    ) = withContext(Dispatchers.IO) {
        val docs = HashMap<Int, PDDocument>()
        val renderers = HashMap<Int, PdfPageSource>()
        // Documento de saída: até 32 MB em memória, o resto vai para arquivo temporário no cache.
        val memory = MemoryUsageSetting.setupMixed(32L * 1024 * 1024).setTempDir(appContext.cacheDir)
        val out = PDDocument(memory)
        try {
            for ((index, item) in pages.withIndex()) {
                onProgress(index, pages.size)
                when (val ref = item.ref) {
                    is PdfPageRef -> {
                        val doc = docs.getOrPut(ref.source) {
                            PDDocument.load(
                                sources[ref.source],
                                MemoryUsageSetting.setupMixed(32L * 1024 * 1024).setTempDir(appContext.cacheDir),
                            )
                        }
                        val srcPage = doc.getPage(ref.page)
                        if (!item.enhance) {
                            val imported = out.importPage(srcPage)
                            if (item.stripImages) removeImages(out, imported)
                        } else {
                            val widthPts = pageWidthPoints(srcPage)
                            val target = (widthPts * 3f).toInt().coerceIn(1400, 2400)
                            val raw: Bitmap? = if (item.stripImages) {
                                renderWithoutImages(srcPage, target)
                            } else {
                                renderers.getOrPut(ref.source) { PdfPageSource(sources[ref.source]) }
                                    .render(ref.page, target)
                            }
                            if (raw == null) {
                                out.importPage(srcPage) // não deu para desenhar: mantém a original
                            } else {
                                val better = ImageEnhancer.enhance(raw, level)
                                raw.recycle()
                                addImagePage(out, better, widthPts)
                                better.recycle()
                            }
                        }
                    }

                    is ImagePageRef -> {
                        val raw = loadImageFile(ref.file, 2400)
                            ?: throw IllegalStateException("não foi possível abrir uma das imagens")
                        val finalBitmap = if (item.enhance) {
                            ImageEnhancer.enhance(raw, level).also { raw.recycle() }
                        } else {
                            raw
                        }
                        addImagePage(out, finalBitmap, A4_WIDTH_POINTS)
                        finalBitmap.recycle()
                    }
                }
            }
            onProgress(pages.size, pages.size)
            out.save(output)
        } finally {
            runCatching { out.close() }
            docs.values.forEach { runCatching { it.close() } }
            renderers.values.forEach { it.close() }
        }
    }

    private fun pageWidthPoints(page: PDPage): Float {
        val box = page.cropBox
        val rotation = page.rotation
        return if (rotation == 90 || rotation == 270) box.height else box.width
    }

    private fun addImagePage(out: PDDocument, bitmap: Bitmap, widthPoints: Float) {
        val heightPoints = widthPoints * bitmap.height / bitmap.width
        val page = PDPage(PDRectangle(widthPoints, heightPoints))
        out.addPage(page)
        val image = JPEGFactory.createFromImage(out, bitmap, 0.92f)
        PDPageContentStream(out, page).use { it.drawImage(image, 0f, 0f, widthPoints, heightPoints) }
    }

    /** Desenha a página como ela ficaria sem as imagens (para melhorar o que sobrou). */
    private suspend fun renderWithoutImages(srcPage: PDPage, target: Int): Bitmap? {
        val tmpDoc = PDDocument()
        val tmpFile = File(appContext.cacheDir, "strip-${System.nanoTime()}.pdf")
        return try {
            val imported = tmpDoc.importPage(srcPage)
            removeImages(tmpDoc, imported)
            tmpDoc.save(tmpFile)
            tmpDoc.close()
            val source = PdfPageSource(tmpFile)
            try {
                source.render(0, target)
            } finally {
                source.close()
            }
        } finally {
            runCatching { tmpDoc.close() }
            tmpFile.delete()
        }
    }

    /**
     * Remove da página as imagens desenhadas diretamente nela (operador "Do" de uma imagem e
     * imagens embutidas "BI"). Imagens dentro de formulários aninhados não são tocadas.
     */
    private fun removeImages(doc: PDDocument, page: PDPage) {
        val resources = page.resources ?: return
        val parser = PDFStreamParser(page)
        val tokens = ArrayList<Any>()
        var token = parser.parseNextToken()
        while (token != null) {
            tokens.add(token)
            token = parser.parseNextToken()
        }

        val kept = ArrayList<Any>(tokens.size)
        for (t in tokens) {
            if (t is Operator) {
                when (t.name) {
                    "BI" -> continue
                    "Do" -> {
                        val name = kept.lastOrNull() as? COSName
                        val isImage = name != null &&
                            runCatching { resources.getXObject(name) is PDImageXObject }
                                .getOrDefault(false)
                        if (isImage) {
                            kept.removeAt(kept.size - 1) // o nome da imagem, operando do "Do"
                            continue
                        }
                    }
                }
            }
            kept.add(t)
        }

        val newContents = PDStream(doc)
        val stream = newContents.createOutputStream(COSName.FLATE_DECODE)
        try {
            ContentStreamWriter(stream).writeTokens(kept)
        } finally {
            stream.close()
        }
        page.setContents(newContents)
    }

    private companion object {
        /** Largura de uma página A4 em pontos (1/72 de polegada). */
        const val A4_WIDTH_POINTS = 595f
    }
}
