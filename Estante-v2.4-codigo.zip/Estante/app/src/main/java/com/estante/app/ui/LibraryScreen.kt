package com.estante.app.ui

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.BitmapFactory
import android.speech.RecognizerIntent
import android.util.LruCache
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyHorizontalGrid
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.estante.app.data.Book
import com.estante.app.data.BookGroup
import com.estante.app.data.BookRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

// Capa um pouco maior que antes e com proporção de livro (2:3): a imagem aparece inteira, sem cortes.
val CoverWidth = 130.dp
val CoverHeight = 192.dp
const val COVER_RATIO = 130f / 192f

private val coverCache = object : LruCache<String, ImageBitmap>(60) {}

/** Carrega a capa do disco (fora da thread principal) e guarda em cache. */
@Composable
fun rememberCoverBitmap(file: File?): ImageBitmap? {
    val key = file?.path
    val state = produceState<ImageBitmap?>(
        initialValue = key?.let { coverCache.get(it) },
        key,
    ) {
        if (file != null && key != null && value == null) {
            value = withContext(Dispatchers.IO) {
                BitmapFactory.decodeFile(file.path)?.asImageBitmap()?.also { coverCache.put(key, it) }
            }
        }
    }
    return state.value
}

@Composable
fun LibraryScreen(
    books: List<Book>,
    groups: List<BookGroup>,
    repo: BookRepository,
    status: String?,
    onOpen: (Book) -> Unit,
    onInfo: (Book) -> Unit,
    onImport: () -> Unit,
    onOpenSettings: () -> Unit,
    onNewGroup: () -> Unit,
    onEditGroup: (String) -> Unit,
) {
    val context = LocalContext.current
    val scheme = MaterialTheme.colorScheme
    var query by rememberSaveable { mutableStateOf("") }
    val storageError by repo.storageError.collectAsState()

    val filtered = remember(books, query) {
        val q = query.trim()
        if (q.isEmpty()) {
            books
        } else {
            books.filter {
                it.title.contains(q, ignoreCase = true) ||
                    it.author.contains(q, ignoreCase = true) ||
                    it.collection.contains(q, ignoreCase = true) ||
                    it.studio.contains(q, ignoreCase = true)
            }
        }
    }
    val byId = remember(books) { books.associateBy { it.id } }
    val continueReading = remember(books) {
        books
            .filter { !it.read && it.progressFraction() > 0f }
            .sortedByDescending { it.lastReadAt }
            .take(12)
    }

    val voiceLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val text = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!text.isNullOrBlank()) query = text
        }
    }
    val startVoice = {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Buscar livro")
        }
        try {
            voiceLauncher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(
                context,
                "Busca por voz não disponível neste aparelho",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(scheme.background)
    ) {
        LibraryHeader(onNewGroup = onNewGroup, onSettings = onOpenSettings)

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when {
                books.isEmpty() -> CenterHint(
                    "Sua estante está vazia\nToque no + para importar PDF, CBR, CBZ ou EPUB"
                )

                query.isNotBlank() -> {
                    if (filtered.isEmpty()) {
                        CenterHint("Nenhum livro encontrado")
                    } else {
                        SearchResults(filtered, repo, onOpen, onInfo)
                    }
                }

                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 12.dp),
                ) {
                    if (continueReading.isNotEmpty()) {
                        item(key = "continue") {
                            Shelf(
                                title = "Continuar lendo",
                                books = continueReading,
                                repo = repo,
                                emptyHint = null,
                                onEdit = null,
                                onOpen = onOpen,
                                onInfo = onInfo,
                            )
                        }
                    }
                    items(groups, key = { "group-${it.id}" }) { group ->
                        val groupBooks = remember(group.bookIds, byId) {
                            group.bookIds.mapNotNull { byId[it] }
                        }
                        Shelf(
                            title = group.name,
                            books = groupBooks,
                            repo = repo,
                            emptyHint = "Grupo vazio. Toque no lápis para adicionar livros.",
                            onEdit = { onEditGroup(group.id) },
                            onOpen = onOpen,
                            onInfo = onInfo,
                        )
                    }
                    item(key = "all") {
                        Shelf(
                            title = "Todos os livros",
                            books = books,
                            repo = repo,
                            emptyHint = null,
                            onEdit = null,
                            onOpen = onOpen,
                            onInfo = onInfo,
                            twoRows = true,
                        )
                    }
                }
            }
        }

        val message = storageError ?: status
        if (message != null) {
            Text(
                text = message,
                color = if (storageError != null) Danger else scheme.onSurfaceVariant,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
            )
        }

        BottomBar(
            query = query,
            onQueryChange = { query = it },
            onImport = onImport,
            onMic = { startVoice() },
        )
    }
}

@Composable
private fun LibraryHeader(onNewGroup: () -> Unit, onSettings: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 4.dp, top = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = "Estante",
            color = scheme.onBackground,
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp,
            modifier = Modifier.weight(1f),
        )
        CastButton()
        IconButton(onClick = onNewGroup) {
            Icon(
                Icons.Filled.CreateNewFolder,
                contentDescription = "Novo grupo",
                tint = scheme.onSurfaceVariant,
            )
        }
        IconButton(onClick = onSettings) {
            Icon(
                Icons.Filled.Settings,
                contentDescription = "Configurações",
                tint = scheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun CenterHint(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            text = text,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 15.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(32.dp),
        )
    }
}

/**
 * Uma prateleira: título + carrossel de capas. Quando há muitos livros, basta arrastar para o lado.
 * Com [twoRows], a prateleira vira um carrossel de duas fileiras (usado em "Todos os livros").
 */
@Composable
private fun Shelf(
    title: String,
    books: List<Book>,
    repo: BookRepository,
    emptyHint: String?,
    onEdit: (() -> Unit)?,
    onOpen: (Book) -> Unit,
    onInfo: (Book) -> Unit,
    twoRows: Boolean = false,
) {
    val scheme = MaterialTheme.colorScheme
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp, bottom = 6.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(36.dp)
                .padding(start = 16.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = title,
                color = scheme.onBackground,
                fontSize = 19.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false),
            )
            Text(
                text = "  ${books.size}",
                color = scheme.onSurfaceVariant,
                fontSize = 13.sp,
            )
            Spacer(Modifier.weight(1f))
            if (onEdit != null) {
                IconButton(onClick = onEdit, modifier = Modifier.size(36.dp)) {
                    Icon(
                        Icons.Filled.Edit,
                        contentDescription = "Editar grupo",
                        tint = scheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp),
                    )
                }
            }
        }
        Spacer(Modifier.height(4.dp))

        when {
            books.isEmpty() -> Text(
                text = emptyHint.orEmpty(),
                color = scheme.onSurfaceVariant,
                fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            )

            twoRows && books.size > 6 -> LazyHorizontalGrid(
                rows = GridCells.Fixed(2),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(CoverHeight * 2 + 10.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(books, key = { it.id }) { book ->
                    BookCover(
                        book = book,
                        coverFile = repo.coverFileOf(book),
                        modifier = Modifier
                            .width(CoverWidth)
                            .height(CoverHeight),
                        onClick = { onOpen(book) },
                        onLongClick = { onInfo(book) },
                    )
                }
            }

            else -> LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                items(books, key = { it.id }) { book ->
                    BookCover(
                        book = book,
                        coverFile = repo.coverFileOf(book),
                        modifier = Modifier
                            .width(CoverWidth)
                            .height(CoverHeight),
                        onClick = { onOpen(book) },
                        onLongClick = { onInfo(book) },
                    )
                }
            }
        }
    }
}

@Composable
private fun SearchResults(
    books: List<Book>,
    repo: BookRepository,
    onOpen: (Book) -> Unit,
    onInfo: (Book) -> Unit,
) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 104.dp),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        items(books, key = { it.id }) { book ->
            BookCover(
                book = book,
                coverFile = repo.coverFileOf(book),
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(COVER_RATIO),
                onClick = { onOpen(book) },
                onLongClick = { onInfo(book) },
            )
        }
    }
}

/** Capa do livro. A imagem usa "Fit": aparece inteira, sem ser cortada. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun BookCover(
    book: Book,
    coverFile: File?,
    modifier: Modifier,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
) {
    val haptic = LocalHapticFeedback.current
    val bitmap = rememberCoverBitmap(coverFile)
    val coverShape = RoundedCornerShape(10.dp)
    Box(
        modifier = modifier
            .shadow(8.dp, coverShape)
            .clip(coverShape)
            .background(CoverGray)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick?.let { action ->
                    {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        action()
                    }
                },
            )
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap,
                contentDescription = book.title,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            Text(
                text = book.title,
                color = Color(0xFFE6E8F0),
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                maxLines = 5,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(8.dp),
            )
        }

        val fraction = book.progressFraction()
        if (book.read) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(4.dp)
                    .size(18.dp)
                    .clip(CircleShape)
                    .background(Accent),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Filled.Check,
                    contentDescription = "Lido",
                    tint = Color.White,
                    modifier = Modifier.size(12.dp),
                )
            }
        } else if (fraction > 0f) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth(fraction)
                    .height(4.dp)
                    .background(Accent)
            )
        }
    }
}

@Composable
private fun BottomBar(
    query: String,
    onQueryChange: (String) -> Unit,
    onImport: () -> Unit,
    onMic: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(50.dp)
                .clip(CircleShape)
                .background(Accent)
                .clickable(onClick = onImport),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.Filled.Add,
                contentDescription = "Importar livros",
                tint = Color.White,
                modifier = Modifier.size(40.dp),
            )
        }
        Spacer(Modifier.width(8.dp))
        Row(
            modifier = Modifier
                .weight(1f)
                .height(36.dp)
                .border(1.dp, scheme.outline, RoundedCornerShape(18.dp))
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                Icons.Filled.Search,
                contentDescription = null,
                tint = scheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp),
            )
            Spacer(Modifier.width(10.dp))
            BasicTextField(
                value = query,
                onValueChange = onQueryChange,
                singleLine = true,
                textStyle = TextStyle(color = scheme.onBackground, fontSize = 14.sp),
                cursorBrush = SolidColor(Accent),
                modifier = Modifier.weight(1f),
                decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (query.isEmpty()) {
                            Text(
                                "Inserir texto...",
                                color = scheme.onSurfaceVariant,
                                fontSize = 14.sp,
                            )
                        }
                        inner()
                    }
                },
            )
            if (query.isNotEmpty()) {
                Icon(
                    Icons.Filled.Close,
                    contentDescription = "Limpar busca",
                    tint = scheme.onSurfaceVariant,
                    modifier = Modifier
                        .size(20.dp)
                        .clickable { onQueryChange("") },
                )
                Spacer(Modifier.width(8.dp))
            }
            Icon(
                Icons.Filled.Mic,
                contentDescription = "Buscar por voz",
                tint = scheme.onSurfaceVariant,
                modifier = Modifier
                    .size(20.dp)
                    .clickable(onClick = onMic),
            )
        }
    }
}
