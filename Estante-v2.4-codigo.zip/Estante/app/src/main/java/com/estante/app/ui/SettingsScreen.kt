package com.estante.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.estante.app.data.ThemeMode

private const val AUTHOR_CREDIT = "Érik Cunha Weizenmann"

@Composable
fun SettingsScreen(
    themeMode: ThemeMode,
    onThemeChange: (ThemeMode) -> Unit,
    folderName: String,
    bookCount: Int,
    onChangeFolder: () -> Unit,
    onBack: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    val context = LocalContext.current
    val version = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }
            .getOrNull() ?: ""
    }
    BackHandler(onBack = onBack)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(scheme.background)
            .verticalScroll(rememberScrollState()),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 4.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Voltar",
                    tint = scheme.onSurfaceVariant,
                )
            }
            Text(
                text = "Configurações",
                color = scheme.onBackground,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
            )
        }

        SectionTitle("Aparência")
        ThemeOption("Escuro", themeMode == ThemeMode.DARK) { onThemeChange(ThemeMode.DARK) }
        ThemeOption("Claro", themeMode == ThemeMode.LIGHT) { onThemeChange(ThemeMode.LIGHT) }
        ThemeOption("Automático (segue o aparelho)", themeMode == ThemeMode.SYSTEM) {
            onThemeChange(ThemeMode.SYSTEM)
        }

        Divider()

        SectionTitle("Armazenamento")
        Column(Modifier.padding(horizontal = 20.dp)) {
            Text("Pasta do app", color = scheme.onSurfaceVariant, fontSize = 12.sp)
            Text(
                text = folderName,
                color = scheme.onBackground,
                fontSize = 16.sp,
                modifier = Modifier.padding(top = 2.dp),
            )
            Text(
                text = "$bookCount livro(s). Livros, capas, grupos e progresso de leitura ficam " +
                    "salvos nesta pasta.",
                color = scheme.onSurfaceVariant,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 8.dp),
            )
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onChangeFolder) {
                Text("Trocar pasta", color = scheme.onBackground)
            }
            Text(
                text = "Ao trocar, o app passa a usar a estante que estiver na nova pasta. " +
                    "Os arquivos da pasta anterior não são apagados nem movidos.",
                color = scheme.onSurfaceVariant,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 8.dp),
            )
        }

        Divider()

        SectionTitle("Sobre")
        Column(Modifier.padding(horizontal = 20.dp)) {
            Text("Estante", color = scheme.onBackground, fontSize = 16.sp)
            if (version.isNotEmpty()) {
                Text("Versão $version", color = scheme.onSurfaceVariant, fontSize = 13.sp)
            }
            Spacer(Modifier.height(14.dp))
            Text("Créditos", color = scheme.onSurfaceVariant, fontSize = 12.sp)
            Text(
                text = AUTHOR_CREDIT,
                color = scheme.onBackground,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 2.dp),
            )
        }
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        color = Accent,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 6.dp),
    )
}

@Composable
private fun Divider() {
    HorizontalDivider(
        modifier = Modifier.padding(top = 18.dp),
        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
    )
}

@Composable
private fun ThemeOption(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(
            selected = selected,
            onClick = onClick,
            colors = RadioButtonDefaults.colors(selectedColor = Accent),
        )
        Text(label, color = MaterialTheme.colorScheme.onBackground, fontSize = 15.sp)
    }
}

/** Primeira abertura (ou pasta perdida): o app exige uma pasta para guardar a estante. */
@Composable
fun FolderSetupScreen(message: String?, onPick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(scheme.background)
            .verticalScroll(rememberScrollState())
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = "Escolha a pasta da sua estante",
            color = scheme.onBackground,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(14.dp))
        Text(
            text = "A Estante guarda seus livros, capas, grupos e o ponto onde você parou " +
                "numa pasta do seu aparelho. Escolha uma pasta existente ou crie uma nova " +
                "(por exemplo, \"Estante\").",
            color = scheme.onSurfaceVariant,
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(10.dp))
        Text(
            text = "Dica: se o Android não deixar usar a pasta raiz ou \"Download\", crie uma pasta nova.",
            color = scheme.onSurfaceVariant,
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
        )
        if (message != null) {
            Spacer(Modifier.height(16.dp))
            Text(
                text = message,
                color = Accent,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
            )
        }
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = onPick,
            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White),
        ) {
            Text("Escolher pasta")
        }
    }
}

@Composable
fun LoadingScreen(text: String) {
    val scheme = MaterialTheme.colorScheme
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(scheme.background),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        CircularProgressIndicator(color = Accent)
        Text(
            text = text,
            color = scheme.onSurfaceVariant,
            fontSize = 13.sp,
            modifier = Modifier.padding(top = 16.dp),
        )
    }
}
