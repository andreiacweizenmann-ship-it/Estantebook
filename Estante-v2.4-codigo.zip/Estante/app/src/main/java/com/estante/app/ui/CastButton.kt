package com.estante.app.ui

import android.view.ContextThemeWrapper
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.mediarouter.app.MediaRouteButton
import com.estante.app.data.CastController
import com.google.android.gms.cast.framework.CastButtonFactory

/** Ícone de transmitir (Chromecast). Some sozinho se o aparelho não suportar. */
@Composable
fun CastButton(modifier: Modifier = Modifier, darkBackground: Boolean? = null) {
    if (!CastController.available) return
    val dark = darkBackground ?: (MaterialTheme.colorScheme.background.luminance() < 0.5f)
    val themeRes = if (dark) {
        androidx.appcompat.R.style.Theme_AppCompat
    } else {
        androidx.appcompat.R.style.Theme_AppCompat_Light
    }
    AndroidView(
        modifier = modifier.size(48.dp),
        factory = { ctx ->
            val themed = ContextThemeWrapper(ctx, themeRes)
            MediaRouteButton(themed).also { CastButtonFactory.setUpMediaRouteButton(ctx, it) }
        },
    )
}
