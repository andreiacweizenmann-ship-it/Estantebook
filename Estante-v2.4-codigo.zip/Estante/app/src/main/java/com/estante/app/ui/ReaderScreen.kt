package com.estante.app.ui

import android.graphics.Bitmap
import android.util.LruCache
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.estante.app.data.Book
import com.estante.app.data.BookFormat
import com.estante.app.data.BookRepository
import com.estante.app.data.CastController
import com.estante.app.data.PageSource
import com.estante.app.data.PdfPageSource
import com.estante.app.data.ZipPageSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

private val BarColor = ReaderBarColor

/** Tela de leitura: escolhe o leitor conforme o formato e guarda o progresso. */
@Composable
fun ReaderScreen(book: Book, repo: BookRepository, startDark: Boolean, onClose: () -> Unit) {
    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }
    ReaderSystemBars()
    BackHandler(onBack = onClose)

    val bookId = book.id
    // O arquivo mora na pasta escolhida pelo usuário; aqui ele é preparado (copiado) para leitura.
    val fileState = produceState<Result<File>?>(initialValue = null, bookId) {
        value = withContext(Dispatchers.IO) { runCatching { repo.localFile(book) } }
    }
    val onProgress: (Int, Int, Boolean, Float) -> Unit = { page, count, finished, fraction ->
        repo.update(bookId) {
            it.copy(
                lastPage = page,
                pageCount = count,
                read = it.read || finished,
                progress = fraction,
                lastReadAt = System.currentTimeMillis(),
            )
        }
    }

    val result = fileState.value
    when {
        result == null -> Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black),
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = Accent)
                Text(
                    text = "Abrindo livro…",
                    color = Color.White,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(top = 16.dp),
                )
            }
        }

        result.isFailure -> ErrorScreen(
            "Não foi possível abrir este livro.\n${result.exceptionOrNull()?.message.orEmpty()}",
            onClose,
        )

        else -> {
            val file = result.getOrThrow()
            if (book.format == BookFormat.EPUB) {
                EpubReader(
                    book = book,
                    file = file,
                    startDark = startDark,
                    onProgress = onProgress,
                    onClose = onClose,
                )
            } else {
                PagedReader(book = book, file = file, onProgress = onProgress, onClose = onClose)
            }
        }
    }
}

@Composable
fun ErrorScreen(message: String, onClose: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(message, color = Color.White, fontSize = 16.sp, textAlign = TextAlign.Center)
        TextButton(onClick = onClose) { Text("Voltar", color = Accent) }
    }
}

// ============================================================ PDF e quadrinhos

@Composable
private fun PagedReader(
    book: Book,
    file: File,
    onProgress: (Int, Int, Boolean, Float) -> Unit,
    onClose: () -> Unit,
) {
    val source = remember(book.id) {
        runCatching<PageSource> {
            if (book.format == BookFormat.PDF) PdfPageSource(file) else ZipPageSource(file)
        }.getOrNull()
    }
    DisposableEffect(source) {
        onDispose { source?.close() }
    }
    if (source == null || source.pageCount == 0) {
        ErrorScreen("Não foi possível abrir este livro.", onClose)
    } else {
        PagedReaderContent(book, source, onProgress, onClose)
    }
}

@Composable
private fun PagedReaderContent(
    book: Book,
    source: PageSource,
    onProgress: (Int, Int, Boolean, Float) -> Unit,
    onClose: () -> Unit,
) {
    val count = source.pageCount
    val pagerState = rememberPagerState(initialPage = book.lastPage.coerceIn(0, count - 1)) { count }
    var rtl by rememberSaveable { mutableStateOf(false) }
    var showBars by rememberSaveable { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val cache = remember { LruCache<Int, Bitmap>(4) }

    val density = LocalDensity.current.density
    val screenWidthDp = LocalConfiguration.current.screenWidthDp
    val widthPx = (screenWidthDp * density * 1.5f).toInt().coerceIn(600, 1600)

    val progressCallback by rememberUpdatedState(onProgress)
    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect { page ->
            progressCallback(
                page,
                count,
                page == count - 1,
                if (page == 0) 0f else (page + 1f) / count,
            )
        }
    }

    // Pré-carrega as páginas vizinhas.
    LaunchedEffect(pagerState.currentPage, widthPx) {
        val current = pagerState.currentPage
        for (i in listOf(current + 1, current - 1)) {
            if (i in 0 until count && cache.get(i) == null) {
                source.render(i, widthPx)?.let { cache.put(i, it) }
            }
        }
    }

    // Transmissão: sempre que a página muda (ou a conexão começa), manda a página para a TV.
    val castDevice by CastController.device.collectAsState()
    LaunchedEffect(castDevice, pagerState.currentPage) {
        if (castDevice != null) {
            delay(250) // evita enviar páginas intermediárias ao deslizar rápido
            CastController.show(source, pagerState.currentPage)
        }
    }

    fun goBy(delta: Int) {
        val target = (pagerState.currentPage + delta).coerceIn(0, count - 1)
        scope.launch { pagerState.animateScrollToPage(target) }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        HorizontalPager(
            state = pagerState,
            reverseLayout = rtl,
            modifier = Modifier.fillMaxSize(),
        ) { page ->
            ZoomPage(
                index = page,
                source = source,
                cache = cache,
                widthPx = widthPx,
                onTap = { fraction ->
                    when {
                        fraction < 0.25f -> goBy(if (rtl) 1 else -1)
                        fraction > 0.75f -> goBy(if (rtl) -1 else 1)
                        else -> showBars = !showBars
                    }
                },
            )
        }

        AnimatedVisibility(
            visible = showBars,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn(),
            exit = fadeOut(),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BarColor)
                    .padding(horizontal = 4.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = Color.White)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = book.title,
                        color = Color.White,
                        fontSize = 16.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    if (castDevice != null) {
                        Text(
                            text = "Transmitindo para $castDevice",
                            color = Accent,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                CastButton(darkBackground = true)
                TextButton(onClick = { rtl = !rtl }) {
                    Text(if (rtl) "← Mangá" else "→ Normal", color = Accent)
                }
            }
        }

        val current = pagerState.currentPage
        val percent = ((current + 1) * 100f / count).roundToInt().coerceIn(0, 100)
        val pageLabel = "${current + 1} / $count"

        AnimatedVisibility(
            visible = showBars,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(),
            exit = fadeOut(),
        ) {
            ProgressPanel(
                sliderValue = current.toFloat(),
                valueRange = 0f..(count - 1).coerceAtLeast(1).toFloat(),
                onValueChange = { value ->
                    scope.launch { pagerState.scrollToPage(value.roundToInt().coerceIn(0, count - 1)) }
                },
                onValueChangeFinished = null,
                percent = percent,
                pageLabel = pageLabel,
            )
        }

        if (!showBars) {
            MiniProgress(
                percent = percent,
                pageLabel = pageLabel,
                modifier = Modifier.align(Alignment.BottomCenter),
            )
        }
    }
}

private class ZoomState {
    var scale by mutableFloatStateOf(1f)
    var offsetX by mutableFloatStateOf(0f)
    var offsetY by mutableFloatStateOf(0f)

    fun reset() {
        scale = 1f
        offsetX = 0f
        offsetY = 0f
    }

    fun transform(zoom: Float, pan: Offset, width: Float, height: Float) {
        scale = (scale * zoom).coerceIn(1f, 5f)
        val maxX = width * (scale - 1f) / 2f
        val maxY = height * (scale - 1f) / 2f
        offsetX = (offsetX + pan.x).coerceIn(-maxX, maxX)
        offsetY = (offsetY + pan.y).coerceIn(-maxY, maxY)
    }
}

/**
 * Zoom por pinça e arrasto. Com zoom 1x o gesto de um dedo não é consumido,
 * então o HorizontalPager recebe o deslize para virar a página.
 */
private fun Modifier.zoomable(state: ZoomState): Modifier = pointerInput(state) {
    awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false)
        do {
            val event = awaitPointerEvent()
            val pressed = event.changes.count { it.pressed }
            if (pressed >= 2 || state.scale > 1f) {
                val zoom = event.calculateZoom()
                val pan = event.calculatePan()
                state.transform(zoom, pan, size.width.toFloat(), size.height.toFloat())
                event.changes.forEach { change ->
                    if (change.positionChanged()) change.consume()
                }
            }
        } while (event.changes.any { it.pressed })
    }
}

@Composable
private fun ZoomPage(
    index: Int,
    source: PageSource,
    cache: LruCache<Int, Bitmap>,
    widthPx: Int,
    onTap: (Float) -> Unit,
) {
    val bitmapState = produceState<Bitmap?>(cache.get(index), index, widthPx) {
        if (value == null) {
            value = source.render(index, widthPx)?.also { cache.put(index, it) }
        }
    }
    val bitmap = bitmapState.value
    val zoom = remember { ZoomState() }
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    val tapCallback by rememberUpdatedState(onTap)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .clipToBounds()
            .onSizeChanged { boxSize = it }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { offset ->
                        val fraction = if (zoom.scale > 1f || boxSize.width == 0) {
                            0.5f
                        } else {
                            offset.x / boxSize.width
                        }
                        tapCallback(fraction)
                    },
                    onDoubleTap = {
                        if (zoom.scale > 1f) zoom.reset() else zoom.scale = 2.5f
                    },
                )
            }
            .zoomable(zoom),
        contentAlignment = Alignment.Center,
    ) {
        if (bitmap != null) {
            // Fundo: a própria página em miniatura, esticada e suavizada (efeito "YouTube"),
            // fixo (não acompanha o zoom). Funciona em qualquer versão do Android.
            val blurred = remember(bitmap) {
                val w = 48
                val h = (w * bitmap.height / bitmap.width.toFloat()).toInt().coerceAtLeast(1)
                Bitmap.createScaledBitmap(bitmap, w, h, true).asImageBitmap()
            }
            Image(
                bitmap = blurred,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                filterQuality = FilterQuality.Low,
                modifier = Modifier.fillMaxSize(),
            )
            Box(Modifier.fillMaxSize().background(Color(0x66000000)))
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = zoom.scale
                        scaleY = zoom.scale
                        translationX = zoom.offsetX
                        translationY = zoom.offsetY
                    },
            )
        } else {
            CircularProgressIndicator(color = Accent)
        }
    }
}
