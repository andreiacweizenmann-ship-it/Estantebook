package com.estante.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import com.github.junrar.Junrar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedOutputStream
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ImportException(message: String) : Exception(message)

/**
 * Importa arquivos da memória do celular: prepara o "livro" (capa, título, número de páginas)
 * e o envia para a pasta de armazenamento escolhida pelo usuário.
 */
class BookImporter(private val context: Context, private val repo: BookRepository) {

    suspend fun import(uri: Uri): Result<Book> = withContext(Dispatchers.IO) {
        runCatching { doImport(uri) }
    }

    private fun displayName(uri: Uri): String {
        context.contentResolver.query(
            uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) {
                    val value = cursor.getString(index)
                    if (!value.isNullOrBlank()) return value
                }
            }
        }
        return uri.lastPathSegment ?: "livro"
    }

    private fun doImport(uri: Uri): Book {
        val name = displayName(uri)
        val ext = name.substringAfterLast('.', "").lowercase()
        val base = name.substringBeforeLast('.', name).replace('_', ' ').trim()
            .ifEmpty { "Sem título" }
        val format = when (ext) {
            "pdf" -> BookFormat.PDF
            "epub" -> BookFormat.EPUB
            "cbz", "cbr", "zip", "rar" -> BookFormat.COMIC
            else -> throw ImportException("$name: formato não suportado")
        }
        val id = UUID.randomUUID().toString()
        val tmp = File(context.cacheDir, "import-$id.$ext")
        return try {
            val input = context.contentResolver.openInputStream(uri)
                ?: throw ImportException("não foi possível abrir o arquivo")
            input.use { src -> tmp.outputStream().use { dst -> src.copyTo(dst) } }
            val book = when (format) {
                BookFormat.PDF -> importPdf(tmp, id, base)
                BookFormat.COMIC -> importComic(tmp, id, base)
                BookFormat.EPUB -> importEpub(tmp, id, base)
            }
            try {
                repo.add(book)
            } catch (e: Exception) {
                File(repo.booksDir, book.fileName).delete()
                book.coverFileName?.let { File(repo.coversDir, it).delete() }
                throw e
            }
            book
        } catch (e: ImportException) {
            throw ImportException("$name: ${e.message}")
        } catch (e: Exception) {
            throw ImportException("$name: ${friendly(e)}")
        } finally {
            tmp.delete()
        }
    }

    private fun friendly(e: Exception): String = when {
        e is SecurityException -> "arquivo protegido por senha"
        e.javaClass.simpleName.contains("V5") ->
            "RAR versão 5 não é suportado; converta para CBZ"
        else -> e.message ?: e.javaClass.simpleName
    }

    private fun saveCover(id: String, bitmap: Bitmap?): String? {
        if (bitmap == null) return null
        val fileName = "$id.jpg"
        bitmap.saveAsJpeg(File(repo.coversDir, fileName))
        return fileName
    }

    // ---------------------------------------------------------------- PDF

    private fun importPdf(tmp: File, id: String, base: String): Book {
        val dest = File(repo.booksDir, "$id.pdf")
        tmp.copyTo(dest, overwrite = true)
        return try {
            val pfd = ParcelFileDescriptor.open(dest, ParcelFileDescriptor.MODE_READ_ONLY)
            val renderer = PdfRenderer(pfd)
            var pages = 0
            var cover: Bitmap? = null
            try {
                pages = renderer.pageCount
                if (pages == 0) throw ImportException("PDF sem páginas")
                val page = renderer.openPage(0)
                try {
                    val width = 600
                    val height = (width.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    cover = bitmap
                } finally {
                    page.close()
                }
            } finally {
                renderer.close()
                pfd.close()
            }
            Book(
                id = id,
                title = base,
                format = BookFormat.PDF,
                fileName = dest.name,
                coverFileName = saveCover(id, cover),
                pageCount = pages,
            )
        } catch (e: Exception) {
            dest.delete()
            throw e
        }
    }

    // ------------------------------------------------------------ Quadrinhos

    private fun importComic(tmp: File, id: String, base: String): Book {
        val head = ByteArray(8)
        tmp.inputStream().use { it.read(head) }
        val isZip = head[0] == 'P'.code.toByte() && head[1] == 'K'.code.toByte()
        val isRar = head[0] == 'R'.code.toByte() && head[1] == 'a'.code.toByte() &&
            head[2] == 'r'.code.toByte()

        val dest = File(repo.booksDir, "$id.cbz")
        return try {
            when {
                isZip -> tmp.copyTo(dest, overwrite = true)
                isRar -> rarToCbz(tmp, dest)
                else -> throw ImportException("o arquivo não é um ZIP nem um RAR válido")
            }
            val source = ZipPageSource(dest)
            try {
                val count = source.pageCount
                if (count == 0) throw ImportException("nenhuma imagem encontrada")
                val cover = source.decode(0, 600)
                val info = source.comicInfo().orEmpty()
                val series = xmlTag(info, "Series")
                val number = xmlTag(info, "Number")
                val infoTitle = xmlTag(info, "Title")
                val title = when {
                    infoTitle.isNotEmpty() -> infoTitle
                    series.isNotEmpty() && number.isNotEmpty() -> "$series #$number"
                    else -> base
                }
                Book(
                    id = id,
                    title = title,
                    author = xmlTag(info, "Writer"),
                    collection = series,
                    studio = xmlTag(info, "Publisher"),
                    format = BookFormat.COMIC,
                    fileName = dest.name,
                    coverFileName = saveCover(id, cover),
                    pageCount = count,
                )
            } finally {
                source.close()
            }
        } catch (e: Exception) {
            dest.delete()
            throw e
        }
    }

    /** Extrai o RAR e remonta as imagens num CBZ numerado, mantendo a ordem natural. */
    private fun rarToCbz(rar: File, out: File) {
        val workDir = File(context.cacheDir, "rar-${System.nanoTime()}")
        workDir.mkdirs()
        try {
            Junrar.extract(rar, workDir)
            val all = workDir.walkTopDown().filter { it.isFile }.toList()
            val images = all
                .filter { f ->
                    f.name.isImageName() && !f.name.startsWith(".") && !f.path.contains("__MACOSX")
                }
                .sortedWith(Comparator<File> { a, b ->
                    compareNatural(a.relativeTo(workDir).path, b.relativeTo(workDir).path)
                })
            if (images.isEmpty()) throw ImportException("nenhuma imagem encontrada no arquivo")
            val comicInfo = all.firstOrNull { it.name.equals("ComicInfo.xml", ignoreCase = true) }

            ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { zip ->
                zip.setLevel(0)
                images.forEachIndexed { index, file ->
                    val entryName = String.format("%05d.%s", index, file.extension.lowercase())
                    zip.putNextEntry(ZipEntry(entryName))
                    file.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
                if (comicInfo != null) {
                    zip.putNextEntry(ZipEntry("ComicInfo.xml"))
                    comicInfo.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
            }
        } finally {
            workDir.deleteRecursively()
        }
    }

    // ------------------------------------------------------------------ EPUB

    private fun importEpub(tmp: File, id: String, base: String): Book {
        val dest = File(repo.booksDir, "$id.epub")
        tmp.copyTo(dest, overwrite = true)
        return try {
            val doc = EpubDoc(dest)
            try {
                if (doc.spine.isEmpty()) throw ImportException("EPUB sem capítulos")
                val coverPath = doc.coverPath
                val cover = if (coverPath != null) {
                    runCatching {
                        decodeSampled(600) {
                            doc.open(coverPath) ?: ByteArrayInputStream(ByteArray(0))
                        }
                    }.getOrNull()
                } else {
                    null
                }
                Book(
                    id = id,
                    title = doc.title.ifBlank { base },
                    author = doc.author,
                    format = BookFormat.EPUB,
                    fileName = dest.name,
                    coverFileName = saveCover(id, cover),
                    pageCount = doc.spine.size,
                )
            } finally {
                doc.close()
            }
        } catch (e: Exception) {
            dest.delete()
            throw e
        }
    }
}
