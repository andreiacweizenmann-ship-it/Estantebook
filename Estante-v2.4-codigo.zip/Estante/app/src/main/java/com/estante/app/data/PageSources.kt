package com.estante.app.data

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.io.File
import java.util.Collections
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

/** Fonte de páginas-imagem (PDF e quadrinhos). */
interface PageSource : Closeable {
    val pageCount: Int
    suspend fun render(index: Int, targetWidth: Int): Bitmap?
}

class PdfPageSource(file: File) : PageSource {
    private val pfd: ParcelFileDescriptor =
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(pfd)
    private val mutex = Mutex()

    override val pageCount: Int get() = renderer.pageCount

    override suspend fun render(index: Int, targetWidth: Int): Bitmap? = mutex.withLock {
        withContext(Dispatchers.IO) {
            runCatching {
                val page = renderer.openPage(index)
                try {
                    val height = (targetWidth.toFloat() * page.height / page.width)
                        .toInt().coerceIn(1, 6000)
                    val bitmap = Bitmap.createBitmap(targetWidth, height, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bitmap
                } finally {
                    page.close()
                }
            }.getOrNull()
        }
    }

    override fun close() {
        runCatching { renderer.close() }
        runCatching { pfd.close() }
    }
}

/** Quadrinhos em CBZ (ZIP). Arquivos CBR são convertidos para CBZ na importação. */
class ZipPageSource(file: File) : PageSource {
    private val zip = ZipFile(file)
    private val entries: List<ZipEntry> = Collections.list(zip.entries())
        .filter { entry ->
            val name = entry.name
            !entry.isDirectory &&
                name.isImageName() &&
                !name.contains("__MACOSX") &&
                !name.substringAfterLast('/').startsWith(".")
        }
        .sortedWith(Comparator<ZipEntry> { a, b -> compareNatural(a.name, b.name) })

    override val pageCount: Int get() = entries.size

    /** Decodificação síncrona (usada também na importação para gerar a capa). */
    fun decode(index: Int, targetWidth: Int): Bitmap? = runCatching {
        val entry = entries[index]
        decodeSampled(targetWidth) { zip.getInputStream(entry) }
    }.getOrNull()

    /** Lê o ComicInfo.xml (quando existe) para preencher título, autor, coleção e estúdio. */
    fun comicInfo(): String? = runCatching {
        val entry = zip.getEntry("ComicInfo.xml")
            ?: Collections.list(zip.entries()).firstOrNull {
                it.name.substringAfterLast('/').equals("ComicInfo.xml", ignoreCase = true)
            }
        entry?.let { e -> zip.getInputStream(e).use { it.readBytes().toString(Charsets.UTF_8) } }
    }.getOrNull()

    override suspend fun render(index: Int, targetWidth: Int): Bitmap? =
        withContext(Dispatchers.IO) { decode(index, targetWidth) }

    override fun close() {
        runCatching { zip.close() }
    }
}
