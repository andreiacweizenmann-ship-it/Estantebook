package com.estante.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

internal val ReaderBarColor = Color(0xCC000000)

/**
 * Painel inferior da leitura, com as três informações:
 *  1. barra de navegação rápida entre páginas,
 *  2. porcentagem já lida,
 *  3. página atual / total (ex.: 20 / 200).
 */
@Composable
fun ProgressPanel(
    sliderValue: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: (() -> Unit)?,
    percent: Int,
    pageLabel: String,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(ReaderBarColor)
            .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Slider(
            value = sliderValue.coerceIn(valueRange),
            onValueChange = onValueChange,
            onValueChangeFinished = onValueChangeFinished,
            valueRange = valueRange,
            colors = SliderDefaults.colors(
                thumbColor = Accent,
                activeTrackColor = Accent,
                inactiveTrackColor = Color(0xFF444444),
            ),
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(text = "$percent% lido", color = Color.White, fontSize = 13.sp)
            Text(text = pageLabel, color = Color.White, fontSize = 13.sp)
        }
    }
}

/** Selo discreto no rodapé com o progresso, visível enquanto os painéis estão escondidos. */
@Composable
fun MiniProgress(percent: Int, pageLabel: String, modifier: Modifier = Modifier) {
    Text(
        text = "$pageLabel  ·  $percent%",
        color = Color.White,
        fontSize = 11.sp,
        modifier = modifier
            .padding(bottom = 6.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0x99000000))
            .padding(horizontal = 10.dp, vertical = 3.dp),
    )
}
