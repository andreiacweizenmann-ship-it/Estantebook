package com.estante.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.estante.app.data.Book
import com.estante.app.data.BookFormat
import com.estante.app.data.BookGroup
import java.io.File
import kotlin.math.roundToInt

@Composable
fun BookInfoScreen(
    book: Book,
    coverFile: File?,
    groups: List<BookGroup>,
    onBack: () -> Unit,
    onRead: () -> Unit,
    onSave: (Book) -> Unit,
    onDelete: () -> Unit,
    onToggleGroup: (String) -> Unit,
    onEditPdf: (() -> Unit)? = null,
) {
    var editing by rememberSaveable { mutableStateOf(false) }

    BackHandler {
        if (editing) editing = false else onBack()
    }

    if (editing) {
        EditBookScreen(
            book = book,
            onCancel = { editing = false },
            onSave = {
                onSave(it)
                editing = false
            },
            onDelete = onDelete,
        )
    } else {
        InfoContent(
            book = book,
            coverFile = coverFile,
            groups = groups,
            onToggleGroup = onToggleGroup,
            onBack = onBack,
            onRead = onRead,
            onEdit = { editing = true },
            onEditPdf = onEditPdf,
        )
    }
}

@Composable
private fun InfoContent(
    book: Book,
    coverFile: File?,
    groups: List<BookGroup>,
    onToggleGroup: (String) -> Unit,
    onBack: () -> Unit,
    onRead: () -> Unit,
    onEdit: () -> Unit,
    onEditPdf: (() -> Unit)?,
) {
    val scheme = MaterialTheme.colorScheme
    val bitmap = rememberCoverBitmap(coverFile)
    var showGroups by rememberSaveable { mutableStateOf(false) }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(scheme.background)
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(8.dp),
        ) {
            Icon(
                Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Voltar",
                tint = scheme.onSurfaceVariant,
            )
        }

        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .fillMaxWidth()
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                modifier = Modifier
                    .width(160.dp)
                    .height(237.dp)
                    .background(CoverGray)
                    .clickable(onClick = onRead),
                contentAlignment = Alignment.Center,
            ) {
                if (bitmap != null) {
                    Image(
                        bitmap = bitmap,
                        contentDescription = book.title,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
            Spacer(Modifier.height(22.dp))
            Text(
                text = book.title,
                color = scheme.onBackground,
                fontSize = 22.sp,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(12.dp))
            InfoLine(book.author, "Autor")
            InfoLine(book.collection, "Coleção")
            InfoLine(book.studio, "Estúdio")
            Spacer(Modifier.height(6.dp))
            StarRating(rating = book.rating, onChange = null, size = 22.dp)
            Spacer(Modifier.height(8.dp))
            Text(
                text = progressText(book),
                color = scheme.onSurfaceVariant,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = onRead,
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White),
                ) {
                    Text(if (book.progressFraction() > 0f && !book.read) "Continuar leitura" else "Ler")
                }
                OutlinedButton(onClick = { showGroups = true }) {
                    Text("Grupos", color = scheme.onBackground)
                }
            }
            if (onEditPdf != null && book.format == BookFormat.PDF) {
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = onEditPdf) {
                    Text("Editar PDF", color = scheme.onBackground)
                }
            }
        }

        Text(
            text = "Editar",
            color = Accent,
            fontSize = 14.sp,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .clickable(onClick = onEdit)
                .padding(start = 36.dp, end = 24.dp, top = 12.dp, bottom = 20.dp),
        )
    }

    if (showGroups) {
        AlertDialog(
            onDismissRequest = { showGroups = false },
            title = { Text("Grupos") },
            text = {
                if (groups.isEmpty()) {
                    Text(
                        "Você ainda não criou nenhum grupo. Toque no ícone de pasta com \"+\" " +
                            "na tela inicial para criar o primeiro."
                    )
                } else {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        groups.forEach { group ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onToggleGroup(group.id) },
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Checkbox(
                                    checked = book.id in group.bookIds,
                                    onCheckedChange = { onToggleGroup(group.id) },
                                    colors = CheckboxDefaults.colors(checkedColor = Accent),
                                )
                                Text(group.name)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showGroups = false }) { Text("Pronto", color = Accent) }
            },
            containerColor = scheme.surfaceVariant,
            titleContentColor = scheme.onBackground,
            textContentColor = scheme.onBackground,
        )
    }
}

@Composable
private fun InfoLine(value: String, placeholder: String) {
    val empty = value.isBlank()
    Text(
        text = if (empty) placeholder else value,
        color = if (empty) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onBackground,
        fontSize = 14.sp,
        textAlign = TextAlign.Center,
        modifier = Modifier.padding(vertical = 7.dp),
    )
}

private fun progressText(book: Book): String {
    val kind = when (book.format) {
        BookFormat.PDF -> "PDF"
        BookFormat.COMIC -> "Quadrinho"
        BookFormat.EPUB -> "EPUB"
    }
    val unit = if (book.format == BookFormat.EPUB) "capítulos" else "páginas"
    val percent = (book.progressFraction() * 100f).roundToInt().coerceIn(0, 100)
    val position = when {
        book.read -> "Lido"
        book.progressFraction() > 0f -> when (book.format) {
            BookFormat.EPUB -> "$percent% lido"
            else -> "Página ${book.lastPage + 1} de ${book.pageCount} · $percent%"
        }
        else -> "Não iniciado"
    }
    return "$kind · ${book.pageCount} $unit · $position"
}

@Composable
fun StarRating(rating: Int, onChange: ((Int) -> Unit)?, size: Dp) {
    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        for (i in 1..5) {
            val filled = i <= rating
            var modifier = Modifier.size(size)
            if (onChange != null) {
                modifier = modifier.clickable { onChange(if (i == rating) 0 else i) }
            }
            Icon(
                imageVector = if (filled) Icons.Filled.Star else Icons.Filled.StarBorder,
                contentDescription = "$i estrelas",
                tint = if (filled) Gold else MaterialTheme.colorScheme.outline,
                modifier = modifier,
            )
        }
    }
}

@Composable
private fun fieldColors(): androidx.compose.material3.TextFieldColors {
    val scheme = MaterialTheme.colorScheme
    return OutlinedTextFieldDefaults.colors(
        focusedTextColor = scheme.onBackground,
        unfocusedTextColor = scheme.onBackground,
        focusedBorderColor = Accent,
        unfocusedBorderColor = scheme.outline,
        cursorColor = Accent,
        focusedLabelColor = Accent,
        unfocusedLabelColor = scheme.onSurfaceVariant,
    )
}

@Composable
private fun EditBookScreen(
    book: Book,
    onCancel: () -> Unit,
    onSave: (Book) -> Unit,
    onDelete: () -> Unit,
) {
    var title by rememberSaveable(book.id) { mutableStateOf(book.title) }
    var author by rememberSaveable(book.id) { mutableStateOf(book.author) }
    var collection by rememberSaveable(book.id) { mutableStateOf(book.collection) }
    var studio by rememberSaveable(book.id) { mutableStateOf(book.studio) }
    var rating by rememberSaveable(book.id) { mutableStateOf(book.rating) }
    var read by rememberSaveable(book.id) { mutableStateOf(book.read) }
    var confirmDelete by rememberSaveable { mutableStateOf(false) }
    val scheme = MaterialTheme.colorScheme

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(scheme.background)
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Editar livro", color = scheme.onBackground, fontSize = 22.sp)
        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Nome do livro") },
            colors = fieldColors(),
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = author,
            onValueChange = { author = it },
            label = { Text("Autor") },
            singleLine = true,
            colors = fieldColors(),
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = collection,
            onValueChange = { collection = it },
            label = { Text("Coleção") },
            singleLine = true,
            colors = fieldColors(),
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = studio,
            onValueChange = { studio = it },
            label = { Text("Estúdio") },
            singleLine = true,
            colors = fieldColors(),
            modifier = Modifier.fillMaxWidth(),
        )

        Text("Avaliação", color = scheme.onSurfaceVariant, fontSize = 13.sp)
        StarRating(rating = rating, onChange = { rating = it }, size = 36.dp)

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text("Marcar como lido", color = scheme.onBackground, fontSize = 15.sp)
            Switch(
                checked = read,
                onCheckedChange = { read = it },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = Accent,
                ),
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = {
                    onSave(
                        book.copy(
                            title = title.trim().ifEmpty { book.title },
                            author = author.trim(),
                            collection = collection.trim(),
                            studio = studio.trim(),
                            rating = rating,
                            read = read,
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White),
            ) {
                Text("Salvar")
            }
            OutlinedButton(onClick = onCancel) {
                Text("Cancelar", color = scheme.onBackground)
            }
        }

        TextButton(onClick = { confirmDelete = true }) {
            Text("Excluir livro", color = Accent)
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Excluir livro?") },
            text = { Text("\"${book.title}\" será removido da estante e o arquivo apagado da pasta de armazenamento.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    onDelete()
                }) {
                    Text("Excluir", color = Accent)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) {
                    Text("Cancelar", color = scheme.onBackground)
                }
            },
            containerColor = scheme.surfaceVariant,
            titleContentColor = scheme.onBackground,
            textContentColor = scheme.onSurfaceVariant,
        )
    }
}
