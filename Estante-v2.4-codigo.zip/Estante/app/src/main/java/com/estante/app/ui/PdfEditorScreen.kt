package com.estante.app.ui

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.estante.app.data.Book
import com.estante.app.data.BookRepository
import com.estante.app.data.EditPage
import com.estante.app.data.EnhanceLevel
import com.estante.app.data.ImageEnhancer
import com.estante.app.data.ImagePageRef
import com.estante.app.data.PageRef
import com.estante.app.data.PdfEditor
import com.estante.app.data.PdfPageRef
import com.estante.app.data.PdfPageSource
import com.estante.app.data.loadImageFile
import com.estante.app.data.saveAsJpeg
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import java.util.concurrent.atomic.AtomicLong

/**
 * Editor de PDF: juntar com outro PDF, inserir imagens como páginas, remover páginas ou as
 * imagens de dentro delas, reordenar e melhorar a qualidade das imagens. Nada é gravado até
 * o usuário tocar em "Salvar".
 */
@Composable
fun PdfEditorScreen(book: Book, repo: BookRepository, onClose: () -> Unit) {
    val context = LocalContext.current
    val scheme = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val editor = remember { PdfEditor(context.applicationContext) }
    val editDir = remember(book.id) {
        File(context.cacheDir, "edit-${book.id}").apply {
            deleteRecursively()
            mkdirs()
        }
    }

    val sources = remember { ArrayList<File>() }
    val renderers = remember { HashMap<Int, PdfPageSource>() }
    val pages = remember { mutableStateListOf<EditPage>() }
    val ids = remember { AtomicLong(1) }
    var selectedId by remember { mutableStateOf<Long?>(null) }
    var level by remember { mutableStateOf(EnhanceLevel.NORMAL) }
    var loading by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf<String?>(null) }
    var problem by remember { mutableStateOf<String?>(null) }
    var doneMessage by remember { mutableStateOf<String?>(null) }
    var showSave by remember { mutableStateOf(false) }
    var confirmExit by remember { mutableStateOf(false) }
    var previewId by remember { mutableStateOf<Long?>(null) }
    var dirty by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        onDispose {
            renderers.values.forEach { it.close() }
            renderers.clear()
            editDir.deleteRecursively()
        }
    }

    fun insertIndex(): Int {
        val index = pages.indexOfFirst { it.id == selectedId }
        return if (index >= 0) index + 1 else pages.size
    }

    /** Abre [file] como nova fonte de páginas e as insere em [at]. */
    suspend fun addPdfSource(file: File, at: Int): Boolean {
        val source = withContext(Dispatchers.IO) { runCatching { PdfPageSource(file) }.getOrNull() }
            ?: return false
        val count = source.pageCount
        if (count == 0) {
            source.close()
            return false
        }
        val sourceIndex = sources.size
        sources.add(file)
        renderers[sourceIndex] = source
        val added = List(count) { EditPage(ids.getAndIncrement(), PdfPageRef(sourceIndex, it)) }
        pages.addAll(at.coerceIn(0, pages.size), added)
        return true
    }

    suspend fun copyUri(uri: Uri, dest: File): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val input = context.contentResolver.openInputStream(uri) ?: return@runCatching false
            input.use { src -> dest.outputStream().use { dst -> src.copyTo(dst) } }
            true
        }.getOrDefault(false)
    }

    val mergeLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                busy = "Juntando PDF…"
                val file = File(editDir, "src${sources.size}.pdf")
                val ok = copyUri(uri, file) && addPdfSource(file, insertIndex())
                busy = null
                if (ok) dirty = true else {
                    file.delete()
                    problem = "Não foi possível abrir esse PDF (ele pode estar protegido por senha ou danificado)."
                }
            }
        }
    }

    val imageLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            scope.launch {
                busy = "Adicionando imagens…"
                val added = mutableListOf<EditPage>()
                var failed = 0
                for (uri in uris) {
                    val ext = imageExtension(context, uri)
                    val file = File(editDir, "img-${ids.get()}-${System.nanoTime()}.$ext")
                    val ok = copyUri(uri, file) &&
                        withContext(Dispatchers.IO) { loadImageFile(file, 64) != null }
                    if (ok) {
                        added += EditPage(ids.getAndIncrement(), ImagePageRef(file))
                    } else {
                        file.delete()
                        failed++
                    }
                }
                pages.addAll(insertIndex().coerceIn(0, pages.size), added)
                if (added.isNotEmpty()) dirty = true
                busy = null
                if (failed > 0) problem = "$failed imagem(ns) não puderam ser abertas."
            }
        }
    }

    LaunchedEffect(book.id) {
        try {
            val local = repo.localFile(book)
            val copy = File(editDir, "src0.pdf")
            withContext(Dispatchers.IO) { local.copyTo(copy, overwrite = true) }
            if (!addPdfSource(copy, 0)) problem = "Não foi possível abrir este PDF para edição."
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            problem = "Não foi possível preparar o PDF: ${e.message ?: e.javaClass.simpleName}"
        }
        loading = false
    }

    BackHandler {
        when {
            busy != null -> Unit
            previewId != null -> previewId = null
            showSave -> showSave = false
            dirty -> confirmExit = true
            else -> onClose()
        }
    }

    fun save(replace: Boolean) {
        showSave = false
        scope.launch {
            val newId = UUID.randomUUID().toString()
            val outFile = if (replace) File(editDir, "out.pdf") else File(repo.booksDir, "$newId.pdf")
            busy = "Gerando PDF…"
            try {
                val snapshot = pages.toList()
                editor.build(sources.toList(), snapshot, level, outFile) { done, total ->
                    busy = "Processando página ${minOf(done + 1, total)} de $total…"
                }
                busy = "Salvando na estante…"
                val cover = editor.cover(outFile)
                withContext(Dispatchers.IO) {
                    if (replace) {
                        repo.replacePdf(book.id, outFile, snapshot.size, cover)
                    } else {
                        val coverName = cover?.let {
                            val name = "$newId.jpg"
                            it.saveAsJpeg(File(repo.coversDir, name))
                            name
                        }
                        repo.add(
                            book.copy(
                                id = newId,
                                title = "${book.title} (editado)",
                                fileName = outFile.name,
                                coverFileName = coverName,
                                pageCount = snapshot.size,
                                lastPage = 0,
                                progress = 0f,
                                rating = 0,
                                read = false,
                                addedAt = System.currentTimeMillis(),
                                lastReadAt = 0L,
                            )
                        )
                    }
                }
                busy = null
                dirty = false
                doneMessage = if (replace) {
                    "O PDF original foi substituído pela versão editada."
                } else {
                    "Salvei como um novo livro: \"${book.title} (editado)\"."
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                busy = null
                if (!replace) outFile.delete()
                problem = "Não foi possível salvar: ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    val selectedIndex = pages.indexOfFirst { it.id == selectedId }
    val selected = pages.getOrNull(selectedIndex)
    val allEnhanced = pages.isNotEmpty() && pages.all { it.enhance }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(scheme.background)
    ) {
        Column(Modifier.fillMaxSize()) {
            // ---- barra superior
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = {
                    if (busy == null) {
                        if (dirty) confirmExit = true else onClose()
                    }
                }) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Voltar",
                        tint = scheme.onSurfaceVariant,
                    )
                }
                Column(Modifier.weight(1f)) {
                    Text("Editar PDF", color = scheme.onBackground, fontSize = 18.sp)
                    Text(
                        "${pages.size} página(s) · ${book.title}",
                        color = scheme.onSurfaceVariant,
                        fontSize = 12.sp,
                        maxLines = 1,
                    )
                }
                Button(
                    onClick = { showSave = true },
                    enabled = pages.isNotEmpty() && busy == null && dirty,
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White),
                ) {
                    Text("Salvar")
                }
                Spacer(Modifier.width(8.dp))
            }

            // ---- ações gerais
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                SmallAction("Juntar PDF") { mergeLauncher.launch(arrayOf("application/pdf")) }
                SmallAction("Adicionar imagens") { imageLauncher.launch(arrayOf("image/*")) }
                SmallAction(
                    text = if (allEnhanced) "Tirar melhoria de todas" else "Melhorar todas",
                    active = allEnhanced,
                ) {
                    val target = !allEnhanced
                    for (i in pages.indices) pages[i] = pages[i].copy(enhance = target)
                    dirty = true
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text("Intensidade da melhoria", color = scheme.onSurfaceVariant, fontSize = 12.sp)
                for (option in EnhanceLevel.values()) {
                    LevelChip(option.label, option == level) { level = option }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Juntar PDF e Adicionar imagens inserem depois da página selecionada " +
                    "(ou no fim). Toque numa página para editá-la.",
                color = scheme.outline,
                fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 16.dp),
            )

            // ---- páginas
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(104.dp),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(count = pages.size, key = { pages[it].id }) { i ->
                        val page = pages[i]
                        PageCell(
                            number = i + 1,
                            page = page,
                            selected = page.id == selectedId,
                            renderers = renderers,
                        ) {
                            selectedId = if (page.id == selectedId) null else page.id
                        }
                    }
                }
                if (loading) {
                    CircularProgressIndicator(color = Accent, modifier = Modifier.align(Alignment.Center))
                }
            }

            // ---- ações da página selecionada
            if (selected != null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(scheme.surfaceVariant)
                        .padding(vertical = 10.dp),
                ) {
                    Text(
                        "Página ${selectedIndex + 1} de ${pages.size}",
                        color = scheme.onSurfaceVariant,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 16.dp),
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        SmallAction("◀ Mover") {
                            if (selectedIndex > 0) {
                                pages.add(selectedIndex - 1, pages.removeAt(selectedIndex))
                                dirty = true
                            }
                        }
                        SmallAction("Mover ▶") {
                            if (selectedIndex < pages.size - 1) {
                                pages.add(selectedIndex + 1, pages.removeAt(selectedIndex))
                                dirty = true
                            }
                        }
                        SmallAction("Melhorar qualidade", active = selected.enhance) {
                            pages[selectedIndex] = selected.copy(enhance = !selected.enhance)
                            dirty = true
                        }
                        SmallAction("Prévia da melhoria") { previewId = selected.id }
                        if (selected.ref is PdfPageRef) {
                            SmallAction("Remover imagens da página", active = selected.stripImages) {
                                pages[selectedIndex] = selected.copy(stripImages = !selected.stripImages)
                                dirty = true
                            }
                        }
                        SmallAction("Excluir página", danger = true) {
                            pages.removeAt(selectedIndex)
                            selectedId = null
                            dirty = true
                        }
                    }
                }
            }
        }

        // ---- trabalhando…
        val working = busy
        if (working != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xCC000000))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {},
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(32.dp),
                ) {
                    CircularProgressIndicator(color = Accent)
                    Spacer(Modifier.height(16.dp))
                    Text(working, color = Color.White, fontSize = 14.sp, textAlign = TextAlign.Center)
                }
            }
        }
    }

    // ---- prévia
    val previewPage = pages.find { it.id == previewId }
    if (previewPage != null) {
        PreviewDialog(
            page = previewPage,
            renderers = renderers,
            level = level,
            onDismiss = { previewId = null },
        )
    }

    // ---- salvar
    if (showSave) {
        AlertDialog(
            onDismissRequest = { showSave = false },
            title = { Text("Salvar PDF editado") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("${pages.size} página(s). Como você quer salvar?")
                    Button(
                        onClick = { save(replace = false) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White),
                    ) {
                        Text("Salvar como novo livro")
                    }
                    OutlinedButton(
                        onClick = { save(replace = true) },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text("Substituir o original", color = scheme.onBackground)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSave = false }) { Text("Cancelar", color = scheme.onBackground) }
            },
            containerColor = scheme.surfaceVariant,
            titleContentColor = scheme.onBackground,
            textContentColor = scheme.onBackground,
        )
    }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("Descartar alterações?") },
            text = { Text("As mudanças feitas neste PDF ainda não foram salvas.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmExit = false
                    onClose()
                }) { Text("Descartar", color = Accent) }
            },
            dismissButton = {
                TextButton(onClick = { confirmExit = false }) {
                    Text("Continuar editando", color = scheme.onBackground)
                }
            },
            containerColor = scheme.surfaceVariant,
            titleContentColor = scheme.onBackground,
            textContentColor = scheme.onSurfaceVariant,
        )
    }

    val error = problem
    if (error != null) {
        AlertDialog(
            onDismissRequest = { problem = null },
            title = { Text("Atenção") },
            text = { Text(error) },
            confirmButton = {
                TextButton(onClick = {
                    problem = null
                    if (pages.isEmpty() && !loading) onClose()
                }) { Text("OK", color = Accent) }
            },
            containerColor = scheme.surfaceVariant,
            titleContentColor = scheme.onBackground,
            textContentColor = scheme.onSurfaceVariant,
        )
    }

    val done = doneMessage
    if (done != null) {
        AlertDialog(
            onDismissRequest = { },
            title = { Text("PDF salvo") },
            text = { Text(done) },
            confirmButton = {
                TextButton(onClick = {
                    doneMessage = null
                    onClose()
                }) { Text("OK", color = Accent) }
            },
            containerColor = scheme.surfaceVariant,
            titleContentColor = scheme.onBackground,
            textContentColor = scheme.onSurfaceVariant,
        )
    }
}

private fun imageExtension(context: android.content.Context, uri: Uri): String {
    val name = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    }.getOrNull().orEmpty()
    val ext = name.substringAfterLast('.', "").lowercase()
    return if (ext in setOf("jpg", "jpeg", "png", "webp", "gif", "bmp")) ext else "jpg"
}

@Composable
private fun SmallAction(
    text: String,
    active: Boolean = false,
    danger: Boolean = false,
    onClick: () -> Unit,
) {
    val padding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
    if (active) {
        Button(
            onClick = onClick,
            contentPadding = padding,
            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White),
        ) {
            Text(text, fontSize = 13.sp, maxLines = 1)
        }
    } else {
        OutlinedButton(onClick = onClick, contentPadding = padding) {
            Text(
                text,
                fontSize = 13.sp,
                maxLines = 1,
                color = if (danger) Danger else MaterialTheme.colorScheme.onBackground,
            )
        }
    }
}

@Composable
private fun LevelChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier = Modifier
            .clip(shape)
            .background(if (selected) Accent else Color.Transparent)
            .border(1.dp, if (selected) Accent else MaterialTheme.colorScheme.outline, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 5.dp),
    ) {
        Text(
            text,
            fontSize = 12.sp,
            color = if (selected) Color.White else MaterialTheme.colorScheme.onBackground,
        )
    }
}

@Composable
private fun PageCell(
    number: Int,
    page: EditPage,
    selected: Boolean,
    renderers: Map<Int, PdfPageSource>,
    onClick: () -> Unit,
) {
    val thumb by produceState<ImageBitmap?>(null, page.id) {
        value = when (val ref = page.ref) {
            is PdfPageRef -> renderers[ref.source]?.render(ref.page, 320)?.asImageBitmap()
            is ImagePageRef -> withContext(Dispatchers.IO) {
                loadImageFile(ref.file, 320)?.asImageBitmap()
            }
        }
    }
    val shape = RoundedCornerShape(6.dp)
    Box(
        modifier = Modifier
            .aspectRatio(0.72f)
            .clip(shape)
            .background(CoverGray)
            .then(if (selected) Modifier.border(3.dp, Accent, shape) else Modifier)
            .clickable(onClick = onClick),
    ) {
        thumb?.let {
            Image(
                bitmap = it,
                contentDescription = "Página $number",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize(),
            )
        }
        Text(
            text = "$number",
            color = Color.White,
            fontSize = 11.sp,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(4.dp)
                .background(Color(0xAA000000), RoundedCornerShape(4.dp))
                .padding(horizontal = 5.dp, vertical = 1.dp),
        )
        val tags = buildString {
            if (page.ref is ImagePageRef) append("🖼 ")
            if (page.enhance) append("✨ ")
            if (page.stripImages) append("🚫🖼")
        }.trim()
        if (tags.isNotEmpty()) {
            Text(
                text = tags,
                fontSize = 11.sp,
                color = Color.White,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(4.dp)
                    .background(Color(0xAA000000), RoundedCornerShape(4.dp))
                    .padding(horizontal = 5.dp, vertical = 1.dp),
            )
        }
    }
}

/** Mostra a página em tamanho grande, com a opção de alternar entre original e melhorada. */
@Composable
private fun PreviewDialog(
    page: EditPage,
    renderers: Map<Int, PdfPageSource>,
    level: EnhanceLevel,
    onDismiss: () -> Unit,
) {
    var showOriginal by remember { mutableStateOf(false) }
    val result by produceState<Pair<ImageBitmap, ImageBitmap>?>(null, page.id, level) {
        value = withContext(Dispatchers.IO) {
            val ref: PageRef = page.ref
            val original = when (ref) {
                is PdfPageRef -> renderers[ref.source]?.render(ref.page, 1400)
                is ImagePageRef -> loadImageFile(ref.file, 1400)
            }
            if (original == null) {
                null
            } else {
                val better = ImageEnhancer.enhance(original, level)
                original.asImageBitmap() to better.asImageBitmap()
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            val pair = result
            if (pair == null) {
                CircularProgressIndicator(color = Accent, modifier = Modifier.align(Alignment.Center))
            } else {
                Image(
                    bitmap = if (showOriginal) pair.first else pair.second,
                    contentDescription = "Prévia",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 64.dp),
                )
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(
                        if (showOriginal) "Original" else "Melhorada (${level.label})",
                        color = Color.White,
                        fontSize = 14.sp,
                    )
                    Switch(
                        checked = showOriginal,
                        onCheckedChange = { showOriginal = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Accent),
                    )
                }
            }
            IconButton(
                onClick = onDismiss,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp),
            ) {
                Icon(Icons.Filled.Close, contentDescription = "Fechar", tint = Color.White)
            }
        }
    }
}
