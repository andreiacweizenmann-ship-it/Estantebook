package com.estante.app.data

import android.net.Uri
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.Closeable
import java.io.File
import java.io.InputStream
import java.util.zip.ZipFile

/** Leitor mínimo de EPUB: metadados, capa e a ordem dos capítulos (spine). */
class EpubDoc(file: File) : Closeable {
    private val zip = ZipFile(file)
    private val spineList = ArrayList<String>()
    private val sizeList = ArrayList<Long>()

    var title: String = ""
        private set
    var author: String = ""
        private set
    var coverPath: String? = null
        private set

    val spine: List<String> get() = spineList

    /** Tamanho (em bytes) de cada capítulo; serve para estimar a posição no livro inteiro. */
    val spineSizes: List<Long> get() = sizeList

    fun totalSize(): Long = sizeList.sum().coerceAtLeast(1L)

    /** Fração (0..1) do livro em que começa [inChapter] (0..1) dentro do [chapter]. */
    fun fractionAt(chapter: Int, inChapter: Float): Float {
        if (sizeList.isEmpty()) return 0f
        val index = chapter.coerceIn(0, sizeList.lastIndex)
        var before = 0L
        for (i in 0 until index) before += sizeList[i]
        val position = before + sizeList[index] * inChapter.coerceIn(0f, 1f)
        return (position.toDouble() / totalSize()).toFloat().coerceIn(0f, 1f)
    }

    /** Inverso de [fractionAt]: devolve (capítulo, fração dentro do capítulo). */
    fun locate(fraction: Float): Pair<Int, Float> {
        if (sizeList.isEmpty()) return 0 to 0f
        val target = fraction.coerceIn(0f, 1f).toDouble() * totalSize()
        var before = 0L
        for (i in sizeList.indices) {
            val size = sizeList[i]
            if (target < before + size || i == sizeList.lastIndex) {
                return i to ((target - before) / size).toFloat().coerceIn(0f, 1f)
            }
            before += size
        }
        return 0 to 0f
    }

    init {
        parse()
    }

    private class Item(val href: String, val type: String, val props: String)

    private fun parse() {
        val container = readText("META-INF/container.xml")
            ?: throw IllegalStateException("EPUB inválido (sem container.xml)")
        val opfPath = Regex("full-path\\s*=\\s*[\"']([^\"']+)[\"']")
            .find(container)?.groupValues?.get(1)
            ?: throw IllegalStateException("EPUB inválido (sem arquivo OPF)")
        val opfDir = opfPath.substringBeforeLast('/', "")
        val stream = open(opfPath)
            ?: throw IllegalStateException("EPUB inválido (OPF ausente)")

        val parser = Xml.newPullParser()
        parser.setInput(stream, null)

        val manifest = HashMap<String, Item>()
        val order = ArrayList<String>()
        var coverId: String? = null
        var coverByProperty: String? = null

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                when (parser.name.substringAfter(':')) {
                    "title" -> {
                        val text = safeText(parser)
                        if (title.isEmpty()) title = text
                    }
                    "creator" -> {
                        val text = safeText(parser)
                        if (author.isEmpty()) author = text
                    }
                    "meta" -> {
                        if (parser.getAttributeValue(null, "name") == "cover") {
                            coverId = parser.getAttributeValue(null, "content")
                        }
                    }
                    "item" -> {
                        val id = parser.getAttributeValue(null, "id")
                        val href = parser.getAttributeValue(null, "href")
                        if (id != null && href != null) {
                            val item = Item(
                                href,
                                parser.getAttributeValue(null, "media-type") ?: "",
                                parser.getAttributeValue(null, "properties") ?: "",
                            )
                            manifest[id] = item
                            if (item.props.contains("cover-image")) {
                                coverByProperty = resolvePath(opfDir, href)
                            }
                        }
                    }
                    "itemref" -> {
                        val idref = parser.getAttributeValue(null, "idref")
                        if (idref != null) order.add(idref)
                    }
                }
            }
            event = parser.next()
        }

        for (idref in order) {
            val item = manifest[idref] ?: continue
            if (item.type.contains("html") || item.href.endsWith("html", ignoreCase = true)) {
                val path = resolvePath(opfDir, item.href)
                spineList.add(path)
                sizeList.add((zip.getEntry(path)?.size ?: 1L).coerceAtLeast(1L))
            }
        }

        val coverItem = coverId?.let { manifest[it] }?.takeIf { it.type.startsWith("image") }
        coverPath = coverByProperty ?: coverItem?.let { resolvePath(opfDir, it.href) }
    }

    private fun safeText(parser: XmlPullParser): String =
        try {
            parser.nextText().trim()
        } catch (e: Exception) {
            ""
        }

    fun open(path: String): InputStream? = zip.getEntry(path)?.let { zip.getInputStream(it) }

    fun readText(path: String): String? =
        open(path)?.use { it.readBytes().toString(Charsets.UTF_8) }

    override fun close() {
        runCatching { zip.close() }
    }

    companion object {
        fun resolvePath(base: String, href: String): String {
            val clean = Uri.decode(href.substringBefore('#').substringBefore('?'))
            val full = when {
                clean.startsWith("/") -> clean.removePrefix("/")
                base.isEmpty() -> clean
                else -> "$base/$clean"
            }
            val parts = ArrayList<String>()
            for (segment in full.split('/')) {
                when (segment) {
                    "", "." -> Unit
                    ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.size - 1)
                    else -> parts.add(segment)
                }
            }
            return parts.joinToString("/")
        }

        fun mimeFor(path: String): String =
            when (path.substringAfterLast('.', "").lowercase()) {
                "html", "htm", "xhtml" -> "text/html"
                "css" -> "text/css"
                "jpg", "jpeg" -> "image/jpeg"
                "png" -> "image/png"
                "gif" -> "image/gif"
                "svg" -> "image/svg+xml"
                "webp" -> "image/webp"
                "ttf" -> "font/ttf"
                "otf" -> "font/otf"
                "woff" -> "font/woff"
                "woff2" -> "font/woff2"
                else -> "application/octet-stream"
            }
    }
}
