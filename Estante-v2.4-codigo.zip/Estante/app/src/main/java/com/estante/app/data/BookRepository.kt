package com.estante.app.data

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.UUID

/**
 * "Banco de dados" da Estante: tudo fica numa pasta escolhida pelo usuário.
 *
 *   <pasta escolhida>/estante.json   lista de livros, grupos e progresso
 *   <pasta escolhida>/livros/        os arquivos (PDF, CBZ, EPUB)
 *   <pasta escolhida>/capas/         as capas
 *
 * O acesso é feito pelo Storage Access Framework (sem permissão de armazenamento).
 * Para ler, o livro é copiado para uma pasta temporária do app ([booksDir]) e as capas ficam
 * em um cache local ([coversDir]); os dois podem ser apagados a qualquer momento, pois
 * são recriados a partir da pasta do usuário.
 */
class BookRepository(private val context: Context, val treeUri: Uri) {
    private val resolver = context.contentResolver
    private val root: DocumentFile = DocumentFile.fromTreeUri(context, treeUri)
        ?: throw IllegalStateException("pasta inválida")

    /** Nome da pasta escolhida, para mostrar nas configurações. */
    val folderName: String = root.name ?: "pasta selecionada"

    /** Cópias de trabalho dos livros (cache, descartável). */
    val booksDir: File = File(context.cacheDir, "work").apply { mkdirs() }

    /** Cache local das capas (recriado a partir da pasta do usuário). */
    val coversDir: File = File(context.filesDir, "covercache").apply { mkdirs() }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val writeMutex = Mutex()
    private var saveJob: Job? = null

    private val bookState = MutableStateFlow<List<Book>>(emptyList())
    private val groupState = MutableStateFlow<List<BookGroup>>(emptyList())
    val books: StateFlow<List<Book>> = bookState.asStateFlow()
    val groups: StateFlow<List<BookGroup>> = groupState.asStateFlow()

    /** Mensagem de erro quando não foi possível gravar na pasta (ex.: sem espaço). */
    val storageError = MutableStateFlow<String?>(null)

    private val booksFolder: DocumentFile by lazy { subFolder(BOOKS_DIR) }
    private val coversFolder: DocumentFile by lazy { subFolder(COVERS_DIR) }
    private var indexDoc: DocumentFile? = null

    // ------------------------------------------------------------ carregar

    /** Lê a estante da pasta. Lança exceção se a pasta não puder ser usada. */
    suspend fun load() = withContext(Dispatchers.IO) {
        if (!root.canRead() || !root.canWrite()) {
            throw IOException("sem permissão de leitura e escrita nesta pasta")
        }
        booksFolder
        coversFolder

        val existing = root.findFile(INDEX_FILE)
        if (existing != null && existing.isFile) {
            indexDoc = existing
            val text = resolver.openInputStream(existing.uri)?.use {
                it.readBytes().toString(Charsets.UTF_8)
            }.orEmpty()
            if (text.isNotBlank()) {
                try {
                    parseIndex(text)
                } catch (e: Exception) {
                    // Não sobrescreve um arquivo que não conseguimos entender.
                    throw IOException("o arquivo $INDEX_FILE desta pasta está ilegível")
                }
            }
        }
        migrateLegacy()
        syncCovers()
    }

    private fun parseIndex(text: String) {
        val trimmed = text.trim()
        val booksArray: JSONArray
        var groupsArray: JSONArray? = null
        if (trimmed.startsWith("[")) {
            booksArray = JSONArray(trimmed)
        } else {
            val obj = JSONObject(trimmed)
            booksArray = obj.optJSONArray("books") ?: JSONArray()
            groupsArray = obj.optJSONArray("groups")
        }
        val loadedBooks = List(booksArray.length()) { Book.fromJson(booksArray.getJSONObject(it)) }
        val loadedGroups = if (groupsArray == null) {
            emptyList()
        } else {
            List(groupsArray.length()) { BookGroup.fromJson(groupsArray.getJSONObject(it)) }
        }
        bookState.value = loadedBooks
        groupState.value = loadedGroups
    }

    /** Baixa para o cache local as capas que ainda não estão neste aparelho. */
    private fun syncCovers() {
        val missing = bookState.value
            .mapNotNull { it.coverFileName }
            .filter { !File(coversDir, it).exists() }
        if (missing.isEmpty()) return
        val remote = coversFolder.listFiles().associateBy { it.name }
        for (name in missing) {
            val doc = remote[name] ?: continue
            runCatching {
                resolver.openInputStream(doc.uri)?.use { input ->
                    File(coversDir, name).outputStream().use { input.copyTo(it) }
                }
            }
        }
    }

    /** Versão 1 do app guardava tudo na memória interna; leva esses livros para a pasta nova. */
    private fun migrateLegacy() {
        val legacyIndex = File(context.filesDir, "library.json")
        if (!legacyIndex.exists()) return
        val legacyBooksDir = File(context.filesDir, "books")
        val legacyCoversDir = File(context.filesDir, "covers")
        val legacy = runCatching {
            val arr = JSONArray(legacyIndex.readText())
            List(arr.length()) { Book.fromJson(arr.getJSONObject(it)) }
        }.getOrNull() ?: return

        val known = bookState.value.map { it.id }.toSet()
        val migrated = mutableListOf<Book>()
        var allGood = true
        for (book in legacy) {
            if (book.id in known) continue
            val source = File(legacyBooksDir, book.fileName)
            if (!source.exists()) continue
            try {
                val remoteName = upload(booksFolder, source, book.fileName, mimeFor(book.fileName))
                val remoteCover = book.coverFileName?.let { cover ->
                    val coverFile = File(legacyCoversDir, cover)
                    if (coverFile.exists()) {
                        coverFile.copyTo(File(coversDir, cover), overwrite = true)
                        upload(coversFolder, coverFile, cover, "image/jpeg")
                    } else {
                        null
                    }
                }
                migrated += book.copy(fileName = remoteName, coverFileName = remoteCover)
            } catch (e: Exception) {
                allGood = false
            }
        }
        if (migrated.isNotEmpty()) {
            bookState.value = migrated + bookState.value
            if (!writeIndexBlocking()) return
        }
        if (allGood) {
            legacyIndex.renameTo(File(context.filesDir, "library.json.migrated"))
            legacyBooksDir.deleteRecursively()
            legacyCoversDir.deleteRecursively()
        }
    }

    // ------------------------------------------------------------ arquivos

    fun coverFileOf(book: Book): File? = book.coverFileName?.let { File(coversDir, it) }

    /** Devolve uma cópia local do livro (copiando da pasta do usuário se for preciso). */
    suspend fun localFile(book: Book): File = withContext(Dispatchers.IO) {
        val ext = book.fileName.substringAfterLast('.', "bin")
        val local = File(booksDir, "${book.id}.$ext")
        if (local.exists() && local.length() > 0) {
            local.setLastModified(System.currentTimeMillis())
            return@withContext local
        }
        val doc = booksFolder.findFile(book.fileName)
            ?: throw IOException("o arquivo do livro não foi encontrado na pasta")
        val part = File(booksDir, "${book.id}.part")
        val input = resolver.openInputStream(doc.uri)
            ?: throw IOException("não foi possível ler o arquivo na pasta")
        input.use { src -> part.outputStream().use { dst -> src.copyTo(dst) } }
        local.delete()
        if (!part.renameTo(local)) throw IOException("falha ao preparar o livro")
        trimWorkDir(keep = local)
        local
    }

    /** Mantém só as cópias de trabalho mais recentes, para não ocupar espaço à toa. */
    private fun trimWorkDir(keep: File) {
        val others = booksDir.listFiles()
            ?.filter { it.isFile && it != keep }
            ?.sortedByDescending { it.lastModified() }
            ?: return
        others.drop(3).forEach { it.delete() }
    }

    private fun subFolder(name: String): DocumentFile {
        val existing = root.findFile(name)
        if (existing != null && existing.isDirectory) return existing
        return root.createDirectory(name)
            ?: throw IOException("não foi possível criar a pasta \"$name\"")
    }

    private fun mimeFor(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "pdf" -> "application/pdf"
        "epub" -> "application/epub+zip"
        "jpg", "jpeg" -> "image/jpeg"
        "json" -> "application/json"
        else -> "application/octet-stream"
    }

    /** Copia um arquivo local para dentro de [dir]; devolve o nome que ficou na pasta. */
    private fun upload(dir: DocumentFile, local: File, name: String, mime: String): String {
        dir.findFile(name)?.delete()
        val doc = dir.createFile(mime, name)
            ?: throw IOException("não foi possível criar \"$name\" na pasta")
        try {
            val out = resolver.openOutputStream(doc.uri, "w")
                ?: throw IOException("não foi possível gravar na pasta")
            out.use { dst -> local.inputStream().use { it.copyTo(dst) } }
        } catch (e: Exception) {
            runCatching { doc.delete() }
            throw e
        }
        return doc.name ?: name
    }

    // ------------------------------------------------------------ livros

    /** Envia o livro (e a capa) já preparados em [booksDir]/[coversDir] para a pasta e registra na estante. */
    fun add(book: Book) {
        val bookFile = File(booksDir, book.fileName)
        val remoteName = upload(booksFolder, bookFile, book.fileName, mimeFor(book.fileName))
        val remoteCover = book.coverFileName?.let { cover ->
            val coverFile = File(coversDir, cover)
            if (coverFile.exists()) upload(coversFolder, coverFile, cover, "image/jpeg") else null
        }
        val stored = book.copy(fileName = remoteName, coverFileName = remoteCover)
        mutateBooks { listOf(stored) + it }
    }

    /**
     * Troca o arquivo de um PDF já existente pelo editado ([local]), mantendo avaliação,
     * grupos e o resto das informações. A capa é refeita se [cover] for informada.
     */
    fun replacePdf(id: String, local: File, pageCount: Int, cover: Bitmap?) {
        val book = bookState.value.find { it.id == id }
            ?: throw IOException("o livro não está mais na estante")
        val remoteName = upload(booksFolder, local, book.fileName, "application/pdf")
        local.copyTo(File(booksDir, "${book.id}.pdf"), overwrite = true)

        var coverName = book.coverFileName
        if (cover != null) {
            val name = coverName ?: "${book.id}.jpg"
            val coverFile = File(coversDir, name)
            cover.saveAsJpeg(coverFile)
            coverName = upload(coversFolder, coverFile, name, "image/jpeg")
        }
        mutateBooks { list ->
            list.map {
                if (it.id != id) {
                    it
                } else {
                    it.copy(
                        fileName = remoteName,
                        coverFileName = coverName,
                        pageCount = pageCount,
                        lastPage = it.lastPage.coerceAtMost(pageCount - 1).coerceAtLeast(0),
                    )
                }
            }
        }
    }

    fun update(id: String, change: (Book) -> Book) = mutateBooks { list ->
        list.map { if (it.id == id) change(it) else it }
    }

    fun delete(id: String) {
        val book = bookState.value.find { it.id == id } ?: return
        File(booksDir, "${book.id}.${book.fileName.substringAfterLast('.', "bin")}").delete()
        coverFileOf(book)?.delete()
        scope.launch {
            runCatching { booksFolder.findFile(book.fileName)?.delete() }
            runCatching { book.coverFileName?.let { coversFolder.findFile(it)?.delete() } }
        }
        mutateBooks { list -> list.filterNot { it.id == id } }
        mutateGroups { list -> list.map { g -> g.copy(bookIds = g.bookIds.filterNot { it == id }) } }
    }

    // ------------------------------------------------------------ grupos

    fun createGroup(name: String, bookIds: List<String>): String {
        val id = UUID.randomUUID().toString()
        val valid = validIds(bookIds)
        mutateGroups { it + BookGroup(id, name.trim().ifEmpty { "Grupo" }, valid) }
        return id
    }

    fun updateGroup(id: String, name: String, bookIds: List<String>) {
        val valid = validIds(bookIds)
        mutateGroups { list ->
            list.map {
                if (it.id == id) it.copy(name = name.trim().ifEmpty { it.name }, bookIds = valid) else it
            }
        }
    }

    fun deleteGroup(id: String) = mutateGroups { list -> list.filterNot { it.id == id } }

    fun toggleBookInGroup(groupId: String, bookId: String) = mutateGroups { list ->
        list.map { g ->
            when {
                g.id != groupId -> g
                bookId in g.bookIds -> g.copy(bookIds = g.bookIds - bookId)
                else -> g.copy(bookIds = g.bookIds + bookId)
            }
        }
    }

    private fun validIds(ids: List<String>): List<String> {
        val existing = bookState.value.map { it.id }.toSet()
        return ids.filter { it in existing }.distinct()
    }

    // ------------------------------------------------------------ gravação

    @Synchronized
    private fun mutateBooks(transform: (List<Book>) -> List<Book>) {
        bookState.value = transform(bookState.value)
        schedulePersist()
    }

    @Synchronized
    private fun mutateGroups(transform: (List<BookGroup>) -> List<BookGroup>) {
        groupState.value = transform(groupState.value)
        schedulePersist()
    }

    /** Grava agora (ex.: quando o app vai para segundo plano). */
    fun flush() = schedulePersist(immediate = true)

    private fun schedulePersist(immediate: Boolean = false) {
        saveJob?.cancel()
        saveJob = scope.launch {
            if (!immediate) delay(SAVE_DELAY_MS)
            writeMutex.withLock { writeIndexBlocking() }
        }
    }

    private fun writeIndexBlocking(): Boolean {
        val json = JSONObject().apply {
            put("version", 2)
            put("books", JSONArray().also { arr -> bookState.value.forEach { arr.put(it.toJson()) } })
            put("groups", JSONArray().also { arr -> groupState.value.forEach { arr.put(it.toJson()) } })
        }
        val bytes = json.toString().toByteArray(Charsets.UTF_8)
        return try {
            val doc = indexDoc?.takeIf { it.exists() }
                ?: root.findFile(INDEX_FILE)
                ?: root.createFile("application/json", INDEX_FILE)
                ?: throw IOException("não foi possível criar $INDEX_FILE")
            indexDoc = doc
            val out = resolver.openOutputStream(doc.uri, "wt")
                ?: throw IOException("não foi possível gravar $INDEX_FILE")
            out.use { it.write(bytes) }
            storageError.value = null
            true
        } catch (e: Exception) {
            indexDoc = null
            storageError.value = "Não foi possível salvar na pasta: ${e.message ?: e.javaClass.simpleName}"
            false
        }
    }

    private companion object {
        const val INDEX_FILE = "estante.json"
        const val BOOKS_DIR = "livros"
        const val COVERS_DIR = "capas"
        const val SAVE_DELAY_MS = 600L
    }
}
