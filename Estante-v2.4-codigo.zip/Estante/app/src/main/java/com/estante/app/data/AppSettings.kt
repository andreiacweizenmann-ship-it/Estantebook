package com.estante.app.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class ThemeMode { DARK, LIGHT, SYSTEM }

/** Preferências deste aparelho (tema e pasta escolhida). O conteúdo da estante fica na pasta do usuário. */
class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("estante_settings", Context.MODE_PRIVATE)

    var themeMode by mutableStateOf(readTheme())
        private set

    fun updateTheme(mode: ThemeMode) {
        themeMode = mode
        prefs.edit().putString(KEY_THEME, mode.name).apply()
    }

    /** URI (texto) da pasta escolhida pelo usuário, ou null se ainda não escolheu. */
    var folderUri: String?
        get() = prefs.getString(KEY_FOLDER, null)
        set(value) {
            prefs.edit().apply {
                if (value == null) remove(KEY_FOLDER) else putString(KEY_FOLDER, value)
            }.apply()
        }

    private fun readTheme(): ThemeMode =
        runCatching { ThemeMode.valueOf(prefs.getString(KEY_THEME, null) ?: "DARK") }
            .getOrDefault(ThemeMode.DARK)

    private companion object {
        const val KEY_THEME = "theme"
        const val KEY_FOLDER = "folder"
    }
}
