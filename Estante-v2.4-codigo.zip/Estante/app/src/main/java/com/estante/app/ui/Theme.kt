package com.estante.app.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

val Accent = Color(0xFF6C63FF) // índigo-violeta: combina com fundos escuros, estilo TV
val Danger = Color(0xFFFF5252)
val CoverGray = Color(0xFF2A2F3D)
val Gold = Color(0xFFFFC107)

private val DarkScheme = darkColorScheme(
    primary = Accent,
    onPrimary = Color.White,
    background = Color(0xFF0B0D14),
    onBackground = Color(0xFFF2F3F7),
    surface = Color(0xFF0B0D14),
    onSurface = Color.White,
    surfaceVariant = Color(0xFF181B26),
    onSurfaceVariant = Color(0xFF9AA0B4),
    outline = Color(0xFF555555),
)

private val LightScheme = lightColorScheme(
    primary = Accent,
    onPrimary = Color.White,
    background = Color(0xFFF7F7F8),
    onBackground = Color(0xFF111111),
    surface = Color(0xFFF7F7F8),
    onSurface = Color(0xFF111111),
    surfaceVariant = Color(0xFFE9E9ED),
    onSurfaceVariant = Color(0xFF5C5C63),
    outline = Color(0xFFB4B4BA),
)

@Composable
fun EstanteTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkScheme else LightScheme,
        content = content,
    )
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/** Pinta a barra de status e a de navegação do sistema. */
@Composable
fun SystemBars(color: Color, darkIcons: Boolean) {
    val view = LocalView.current
    if (view.isInEditMode) return
    SideEffect {
        val window = view.context.findActivity()?.window ?: return@SideEffect
        window.statusBarColor = color.toArgb()
        window.navigationBarColor = color.toArgb()
        val controller = WindowCompat.getInsetsController(window, view)
        controller.isAppearanceLightStatusBars = darkIcons
        controller.isAppearanceLightNavigationBars = darkIcons
    }
}

/** Durante a leitura as barras do sistema ficam pretas; ao sair, volta o que estava antes. */
@Composable
fun ReaderSystemBars() {
    val view = LocalView.current
    if (view.isInEditMode) return
    DisposableEffect(Unit) {
        val window = view.context.findActivity()?.window
        if (window == null) {
            onDispose { }
        } else {
            val controller = WindowCompat.getInsetsController(window, view)
            val previousStatus = window.statusBarColor
            val previousNavigation = window.navigationBarColor
            val previousLightStatus = controller.isAppearanceLightStatusBars
            val previousLightNavigation = controller.isAppearanceLightNavigationBars
            window.statusBarColor = Color.Black.toArgb()
            window.navigationBarColor = Color.Black.toArgb()
            controller.isAppearanceLightStatusBars = false
            controller.isAppearanceLightNavigationBars = false
            onDispose {
                window.statusBarColor = previousStatus
                window.navigationBarColor = previousNavigation
                controller.isAppearanceLightStatusBars = previousLightStatus
                controller.isAppearanceLightNavigationBars = previousLightNavigation
            }
        }
    }
}
