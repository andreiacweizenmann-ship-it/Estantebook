package com.estante.app.ui

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.estante.app.data.Book
import com.estante.app.data.EpubDoc
import java.io.ByteArrayInputStream
import java.io.File
import kotlin.math.abs
import kotlin.math.roundToInt

private val BarColor = ReaderBarColor
private const val PAPER_INT = 0xFFF5F1E8.toInt()

/** Estado da leitura de um EPUB: capítulo atual e página dentro do capítulo. */
private class EpubController(
    val doc: EpubDoc,
    startChapter: Int,
    startFraction: Float?,
    startDark: Boolean,
) {
    var chapter by mutableIntStateOf(startChapter)
    var page by mutableIntStateOf(0)
    var pages by mutableIntStateOf(1)
    var fontPercent by mutableIntStateOf(110)
    var dark by mutableStateOf(startDark)
    var ready by mutableStateOf(false)

    // Variáveis comuns (não precisam redesenhar a tela).
    /** Posição (0..1) dentro do capítulo onde abrir assim que o texto for medido. */
    var pending: Float? = startFraction
    var openLast = false
    var webView: WebView? = null

    fun applyPage() {
        webView?.evaluateJavascript("window.scrollTo(${page} * window.innerWidth, 0);", null)
    }

    /** Fração (0..1) do livro inteiro em que começa a página atual. */
    fun startFraction(): Float =
        doc.fractionAt(chapter, page.toFloat() / pages.coerceAtLeast(1))

    fun next() {
        if (page < pages - 1) {
            page++
            applyPage()
        } else if (chapter < doc.spine.lastIndex) {
            openLast = false
            pending = null
            chapter++
        }
    }

    fun prev() {
        if (page > 0) {
            page--
            applyPage()
        } else if (chapter > 0) {
            openLast = true
            pending = null
            chapter--
        }
    }

    /** Vai para uma posição (0..1) do livro inteiro. */
    fun goToFraction(fraction: Float) {
        val (target, inChapter) = doc.locate(fraction)
        openLast = false
        if (target == chapter) {
            if (ready) {
                page = (inChapter * pages + 0.01f).toInt().coerceIn(0, pages - 1)
                applyPage()
            } else {
                pending = inChapter
            }
        } else {
            pending = inChapter
            chapter = target
        }
    }
}

@Composable
fun EpubReader(
    book: Book,
    file: File,
    startDark: Boolean,
    onProgress: (Int, Int, Boolean, Float) -> Unit,
    onClose: () -> Unit,
) {
    val doc = remember(book.id) { runCatching { EpubDoc(file) }.getOrNull() }
    DisposableEffect(doc) {
        onDispose { doc?.close() }
    }
    if (doc == null || doc.spine.isEmpty()) {
        ErrorScreen("Não foi possível abrir este EPUB.", onClose)
    } else {
        EpubContent(book, doc, startDark, onProgress, onClose)
    }
}

@Composable
private fun EpubContent(
    book: Book,
    doc: EpubDoc,
    startDark: Boolean,
    onProgress: (Int, Int, Boolean, Float) -> Unit,
    onClose: () -> Unit,
) {
    val controller = remember(doc) {
        if (book.progress > 0f) {
            // Retoma exatamente na página onde parou.
            val (chapter, inChapter) = doc.locate(book.progress)
            EpubController(doc, chapter, inChapter, startDark)
        } else {
            EpubController(doc, book.lastPage.coerceIn(0, doc.spine.lastIndex), null, startDark)
        }
    }
    var showBars by rememberSaveable { mutableStateOf(false) }
    val progressCallback by rememberUpdatedState(onProgress)
    var sliderPosition by remember { mutableFloatStateOf(0f) }
    var dragging by remember { mutableStateOf(false) }

    // Só salva depois que o texto foi medido; antes disso a página ainda é "0" de mentira.
    LaunchedEffect(controller.chapter, controller.page, controller.pages, controller.ready) {
        if (!controller.ready) return@LaunchedEffect
        val finished = controller.chapter == doc.spine.lastIndex &&
            controller.page >= controller.pages - 1
        progressCallback(
            controller.chapter,
            doc.spine.size,
            finished,
            controller.startFraction(),
        )
    }

    // Estimativa do livro inteiro: o tamanho de cada capítulo diz quantas "páginas" ele vale.
    val totalSize = remember(doc) { doc.totalSize() }
    val chapterSize = doc.spineSizes[controller.chapter].coerceAtLeast(1L)
    val bytesPerPage = chapterSize.toFloat() / controller.pages.coerceAtLeast(1)
    val totalPages = (totalSize / bytesPerPage).roundToInt().coerceAtLeast(1)
    val livePage = (controller.startFraction() * totalPages + 0.001f).toInt()
        .coerceIn(0, totalPages - 1)
    val dragPage = (sliderPosition * (totalPages - 1)).roundToInt().coerceIn(0, totalPages - 1)
    val shownPage = if (dragging) dragPage else livePage
    val percent = ((shownPage + 1) * 100f / totalPages).roundToInt().coerceIn(0, 100)
    val pageLabel = "${shownPage + 1} / ~$totalPages"
    val sliderValue = when {
        dragging -> sliderPosition
        totalPages > 1 -> livePage.toFloat() / (totalPages - 1)
        else -> 0f
    }

    DisposableEffect(controller) {
        onDispose {
            controller.webView?.destroy()
            controller.webView = null
        }
    }

    val background = if (controller.dark) Color.Black else Color(PAPER_INT)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(background)
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                createWebView(context, controller) { showBars = !showBars }
            },
            update = { view -> loadChapterIfNeeded(view, controller) },
        )

        AnimatedVisibility(
            visible = showBars,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn(),
            exit = fadeOut(),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BarColor)
                    .padding(horizontal = 4.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = Color.White)
                }
                Text(
                    text = book.title,
                    color = Color.White,
                    fontSize = 16.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                TextButton(onClick = {
                    controller.fontPercent = (controller.fontPercent - 10).coerceAtLeast(70)
                }) { Text("A−", color = Accent) }
                TextButton(onClick = {
                    controller.fontPercent = (controller.fontPercent + 10).coerceAtMost(220)
                }) { Text("A+", color = Accent) }
                TextButton(onClick = { controller.dark = !controller.dark }) {
                    Text(if (controller.dark) "Claro" else "Escuro", color = Accent)
                }
            }
        }

        AnimatedVisibility(
            visible = showBars,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(),
            exit = fadeOut(),
        ) {
            ProgressPanel(
                sliderValue = sliderValue,
                valueRange = 0f..1f,
                onValueChange = {
                    dragging = true
                    sliderPosition = it
                },
                onValueChangeFinished = {
                    val target = (sliderPosition * (totalPages - 1)).roundToInt()
                        .coerceIn(0, totalPages - 1)
                    dragging = false
                    controller.goToFraction(target.toFloat() / totalPages)
                },
                percent = percent,
                pageLabel = pageLabel,
            )
        }

        if (!showBars) {
            MiniProgress(
                percent = percent,
                pageLabel = pageLabel,
                modifier = Modifier.align(Alignment.BottomCenter),
            )
        }
    }
}

private fun notFound(): WebResourceResponse =
    WebResourceResponse(
        "text/plain", "UTF-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0))
    )

@SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
private fun createWebView(
    context: Context,
    controller: EpubController,
    onToggleBars: () -> Unit,
): WebView {
    val doc = controller.doc
    val webView = WebView(context)
    controller.webView = webView
    webView.setBackgroundColor(AndroidColor.BLACK)
    webView.isVerticalScrollBarEnabled = false
    webView.isHorizontalScrollBarEnabled = false
    webView.overScrollMode = View.OVER_SCROLL_NEVER
    webView.settings.apply {
        // O JavaScript é usado só para paginar o texto; os <script> do livro são removidos.
        javaScriptEnabled = true
        allowFileAccess = false
        allowContentAccess = false
        domStorageEnabled = false
        setSupportZoom(false)
    }

    webView.webViewClient = object : WebViewClient() {
        override fun shouldInterceptRequest(
            view: WebView?,
            request: WebResourceRequest?,
        ): WebResourceResponse? {
            val uri = request?.url ?: return null
            if (uri.host != "epub.local") return notFound()
            val path = uri.path?.removePrefix("/") ?: return notFound()
            val stream = doc.open(path) ?: return notFound()
            return WebResourceResponse(EpubDoc.mimeFor(path), null, stream)
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            if (view == null) return
            measurePages(view, controller, initial = true)
            view.postDelayed({ measurePages(view, controller, initial = false) }, 600)
        }
    }

    val detector = GestureDetector(
        context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapUp(e: MotionEvent): Boolean {
                val width = webView.width.toFloat()
                when {
                    e.x < width * 0.25f -> controller.prev()
                    e.x > width * 0.75f -> controller.next()
                    else -> onToggleBars()
                }
                return true
            }

            override fun onFling(
                e1: MotionEvent?,
                e2: MotionEvent,
                velocityX: Float,
                velocityY: Float,
            ): Boolean {
                if (abs(velocityX) > abs(velocityY) && abs(velocityX) > 400f) {
                    if (velocityX < 0) controller.next() else controller.prev()
                    return true
                }
                return false
            }
        },
    )
    webView.setOnTouchListener { _, event ->
        detector.onTouchEvent(event)
        true
    }
    return webView
}

private fun measurePages(view: WebView, controller: EpubController, initial: Boolean) {
    val script = "(function(){return Math.max(1,Math.ceil(" +
        "(document.documentElement.scrollWidth-2)/window.innerWidth));})();"
    view.evaluateJavascript(script) { result ->
        val count = result?.trim()?.trim('"')?.toIntOrNull() ?: 1
        controller.pages = count
        if (initial) {
            val target = controller.pending
            controller.page = when {
                controller.openLast -> count - 1
                target != null -> (target * count + 0.01f).toInt().coerceIn(0, count - 1)
                else -> 0
            }
            controller.pending = null
            controller.openLast = false
            controller.ready = true
            controller.applyPage()
        } else {
            controller.page = controller.page.coerceAtMost(count - 1)
        }
    }
}

private fun loadChapterIfNeeded(view: WebView, controller: EpubController) {
    val key = "${controller.chapter}|${controller.fontPercent}|${controller.dark}"
    if (view.tag == key) return
    // Mudou só o tamanho da letra ou o tema: continua no mesmo ponto do capítulo.
    val previousChapter = (view.tag as? String)?.substringBefore('|')
    if (previousChapter == controller.chapter.toString() &&
        controller.ready &&
        controller.pending == null
    ) {
        controller.pending = controller.page.toFloat() / controller.pages.coerceAtLeast(1)
    }
    view.tag = key
    controller.ready = false
    val path = controller.doc.spine[controller.chapter]
    val html = buildHtml(
        controller.doc.readText(path).orEmpty(),
        controller.fontPercent,
        controller.dark,
    )
    view.setBackgroundColor(if (controller.dark) AndroidColor.BLACK else PAPER_INT)
    view.loadDataWithBaseURL(
        "https://epub.local/" + Uri.encode(path, "/"),
        html,
        "text/html",
        "UTF-8",
        null,
    )
}

/** Monta o HTML do capítulo em colunas: cada coluna é uma "página" na tela. */
private fun buildHtml(raw: String, fontPercent: Int, dark: Boolean): String {
    val background = if (dark) "#000000" else "#f5f1e8"
    val foreground = if (dark) "#d8d8d8" else "#1a1a1a"
    val link = if (dark) "#ff6b6b" else "#b3261e"
    val css = "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">" +
        "<style>" +
        "html{overflow:hidden !important;background:$background !important;" +
        "font-size:$fontPercent% !important;}" +
        "body{margin:0 !important;padding:0 !important;background:$background !important;" +
        "color:$foreground !important;}" +
        "#__c{box-sizing:border-box;height:100vh;padding:20px;" +
        "column-width:calc(100vw - 40px);column-gap:40px;column-fill:auto;" +
        "overflow-wrap:break-word;line-height:1.5;}" +
        "#__c *{color:inherit !important;background:transparent !important;" +
        "max-width:100% !important;}" +
        "#__c img,#__c svg{max-height:calc(100vh - 60px) !important;width:auto;" +
        "height:auto;object-fit:contain;}" +
        "#__c a{color:$link !important;}" +
        "</style>"

    val noScripts = raw
        .replace(Regex("<script[\\s\\S]*?</script>", RegexOption.IGNORE_CASE), "")
        .replace(Regex("\\son[a-z]+\\s*=\\s*(\"[^\"]*\"|'[^']*')", RegexOption.IGNORE_CASE), "")

    val bodyOpen = Regex("<body[^>]*>", RegexOption.IGNORE_CASE).find(noScripts)
    if (bodyOpen == null) {
        return "<html><head>$css</head><body><div id=\"__c\">$noScripts</div></body></html>"
    }

    val withHead = if (noScripts.contains("</head>", ignoreCase = true)) {
        noScripts.replaceFirst(
            Regex("</head>", RegexOption.IGNORE_CASE),
            Regex.escapeReplacement(css + "</head>"),
        )
    } else {
        noScripts.replaceFirst(bodyOpen.value, css + bodyOpen.value)
    }
    val open = Regex("<body[^>]*>", RegexOption.IGNORE_CASE).find(withHead) ?: return withHead
    val start = open.range.last + 1
    val closeIndex = withHead.lastIndexOf("</body>", ignoreCase = true)
    val end = if (closeIndex >= start) closeIndex else withHead.length
    return withHead.substring(0, start) +
        "<div id=\"__c\">" +
        withHead.substring(start, end) +
        "</div>" +
        withHead.substring(end)
}
