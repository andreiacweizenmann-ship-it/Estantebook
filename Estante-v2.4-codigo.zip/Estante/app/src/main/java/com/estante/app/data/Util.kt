package com.estante.app.data

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

private val IMAGE_EXTENSIONS = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp")

fun String.isImageName(): Boolean = substringAfterLast('.', "").lowercase() in IMAGE_EXTENSIONS

/** Ordem "natural": pagina2 vem antes de pagina10. */
fun compareNatural(a: String, b: String): Int {
    var i = 0
    var j = 0
    while (i < a.length && j < b.length) {
        if (a[i].isDigit() && b[j].isDigit()) {
            val startA = i
            while (i < a.length && a[i].isDigit()) i++
            val startB = j
            while (j < b.length && b[j].isDigit()) j++
            val na = a.substring(startA, i).trimStart('0')
            val nb = b.substring(startB, j).trimStart('0')
            if (na.length != nb.length) return na.length - nb.length
            val c = na.compareTo(nb)
            if (c != 0) return c
        } else {
            val c = a[i].lowercaseChar().compareTo(b[j].lowercaseChar())
            if (c != 0) return c
            i++
            j++
        }
    }
    return (a.length - i) - (b.length - j)
}

/**
 * Decodifica uma imagem reduzindo o tamanho (para não estourar a memória).
 * [open] é chamado duas vezes: uma para medir e outra para decodificar.
 */
fun decodeSampled(targetWidth: Int, open: () -> InputStream): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    open().use { BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / (sample * 2) >= targetWidth || bounds.outHeight / sample > 4096) {
        sample *= 2
    }
    val options = BitmapFactory.Options().apply { inSampleSize = sample }
    return open().use { BitmapFactory.decodeStream(it, null, options) }
}

fun Bitmap.saveAsJpeg(file: File) {
    FileOutputStream(file).use { compress(Bitmap.CompressFormat.JPEG, 88, it) }
}

fun xmlTag(xml: String, tag: String): String {
    val raw = Regex("<$tag>([\\s\\S]*?)</$tag>").find(xml)?.groupValues?.get(1)?.trim().orEmpty()
    return raw
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&apos;", "'")
        .replace("&amp;", "&")
}
