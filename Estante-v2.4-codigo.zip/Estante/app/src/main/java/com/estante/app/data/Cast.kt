package com.estante.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min

/**
 * Servidor HTTP minúsculo: a TV (Chromecast) busca aqui as páginas que o celular prepara.
 * Guarda só as últimas imagens, para não gastar memória.
 */
private class CastServer {
    private var socket: ServerSocket? = null
    private val images = ConcurrentHashMap<String, ByteArray>()
    private val order = ArrayDeque<String>()

    val port: Int get() = socket?.localPort ?: 0

    @Synchronized
    fun start() {
        if (socket?.isClosed == false) return
        val server = ServerSocket(0)
        socket = server
        thread(isDaemon = true, name = "cast-server") {
            while (!server.isClosed) {
                try {
                    val client = server.accept()
                    thread(isDaemon = true, name = "cast-client") { handle(client) }
                } catch (e: IOException) {
                    break
                }
            }
        }
    }

    @Synchronized
    fun stop() {
        runCatching { socket?.close() }
        socket = null
        images.clear()
        order.clear()
    }

    @Synchronized
    fun put(key: String, bytes: ByteArray) {
        images[key] = bytes
        order.addLast(key)
        while (order.size > 4) images.remove(order.removeFirst())
    }

    private fun handle(client: Socket) {
        runCatching {
            client.use { sock ->
                sock.soTimeout = 10_000
                val reader = sock.getInputStream().bufferedReader(Charsets.ISO_8859_1)
                val requestLine = reader.readLine() ?: return
                while (true) {
                    val line = reader.readLine() ?: break
                    if (line.isEmpty()) break
                }
                val parts = requestLine.split(" ")
                val method = parts.getOrNull(0).orEmpty()
                val path = parts.getOrNull(1).orEmpty()
                val key = path.substringAfterLast('/').substringBefore('?').substringBefore('.')
                val data = images[key]
                val out = sock.getOutputStream()
                val cors = "Access-Control-Allow-Origin: *\r\nAccess-Control-Allow-Headers: *\r\n"
                if (data == null) {
                    out.write(("HTTP/1.1 404 Not Found\r\n${cors}Content-Length: 0\r\nConnection: close\r\n\r\n").toByteArray())
                } else {
                    val head = "HTTP/1.1 200 OK\r\nContent-Type: image/jpeg\r\nContent-Length: ${data.size}\r\n" +
                        "${cors}Cache-Control: no-store\r\nConnection: close\r\n\r\n"
                    out.write(head.toByteArray())
                    if (method != "HEAD") out.write(data)
                }
                out.flush()
            }
        }
    }
}

/** Controla a transmissão para o Chromecast: sessão, servidor local e envio das páginas. */
object CastController {
    private var castContext: CastContext? = null
    private val server = CastServer()
    private val _device = MutableStateFlow<String?>(null)

    /** Nome do aparelho conectado (ex.: "TV da sala"), ou null quando não está transmitindo. */
    val device: StateFlow<String?> = _device

    val available: Boolean get() = castContext != null

    private val listener = object : SessionManagerListener<CastSession> {
        private fun connected(session: CastSession) {
            _device.value = session.castDevice?.friendlyName ?: "Chromecast"
        }

        private fun disconnected() {
            _device.value = null
            server.stop()
        }

        override fun onSessionStarting(session: CastSession) {}
        override fun onSessionStarted(session: CastSession, sessionId: String) = connected(session)
        override fun onSessionStartFailed(session: CastSession, error: Int) = disconnected()
        override fun onSessionEnding(session: CastSession) {}
        override fun onSessionEnded(session: CastSession, error: Int) = disconnected()
        override fun onSessionResuming(session: CastSession, sessionId: String) {}
        override fun onSessionResumed(session: CastSession, wasSuspended: Boolean) = connected(session)
        override fun onSessionResumeFailed(session: CastSession, error: Int) = disconnected()
        override fun onSessionSuspended(session: CastSession, reason: Int) {}
    }

    /** Chamar uma vez, na abertura do app. Se o aparelho não tem Google Play Services, o Cast fica oculto. */
    fun init(context: Context) {
        if (castContext != null) return
        val ctx = runCatching { CastContext.getSharedInstance(context.applicationContext) }.getOrNull() ?: return
        castContext = ctx
        ctx.sessionManager.addSessionManagerListener(listener, CastSession::class.java)
        val current = ctx.sessionManager.currentCastSession
        if (current != null && current.isConnected) {
            _device.value = current.castDevice?.friendlyName ?: "Chromecast"
        }
    }

    /**
     * Prepara a página em 1920x1080 (página inteira no centro, fundo desfocado nas laterais)
     * e manda para a TV. Não faz nada se não houver transmissão ativa.
     */
    suspend fun show(source: PageSource, index: Int) {
        val session = castContext?.sessionManager?.currentCastSession ?: return
        if (!session.isConnected) return
        val client = session.remoteMediaClient ?: return

        val bytes = withContext(Dispatchers.Default) {
            val page = source.render(index, 1280) ?: return@withContext null
            try {
                composeFrame(page)
            } finally {
                page.recycle()
            }
        } ?: return

        val ip = localIp() ?: return
        server.start()
        val key = "p${System.nanoTime()}"
        server.put(key, bytes)
        val url = "http://$ip:${server.port}/$key.jpg"

        val info = MediaInfo.Builder(url)
            .setStreamType(MediaInfo.STREAM_TYPE_NONE)
            .setContentType("image/jpeg")
            .setMetadata(MediaMetadata(MediaMetadata.MEDIA_TYPE_PHOTO))
            .build()
        withContext(Dispatchers.Main) {
            client.load(MediaLoadRequestData.Builder().setMediaInfo(info).setAutoplay(true).build())
        }
    }

    private fun composeFrame(page: Bitmap): ByteArray {
        val w = 1920
        val h = 1080
        val frame = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(frame)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

        // Fundo: miniatura da página esticada até cobrir a tela (fica suave/desfocada).
        val sw = 48
        val sh = (sw * page.height / page.width.toFloat()).toInt().coerceAtLeast(1)
        val tiny = Bitmap.createScaledBitmap(page, sw, sh, true)
        val cover = max(w / sw.toFloat(), h / sh.toFloat())
        val bw = sw * cover
        val bh = sh * cover
        canvas.drawBitmap(tiny, null, RectF((w - bw) / 2, (h - bh) / 2, (w + bw) / 2, (h + bh) / 2), paint)
        tiny.recycle()
        canvas.drawColor(0x66000000)

        // Página inteira, centralizada, sem cortes.
        val fit = min(w / page.width.toFloat(), h / page.height.toFloat())
        val pw = page.width * fit
        val ph = page.height * fit
        canvas.drawBitmap(page, null, RectF((w - pw) / 2, (h - ph) / 2, (w + pw) / 2, (h + ph) / 2), paint)

        val out = ByteArrayOutputStream()
        frame.compress(Bitmap.CompressFormat.JPEG, 88, out)
        frame.recycle()
        return out.toByteArray()
    }

    private fun localIp(): String? = runCatching {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }
            .filterIsInstance<Inet4Address>()
            .firstOrNull { it.isSiteLocalAddress }
            ?.hostAddress
    }.getOrNull()
}
