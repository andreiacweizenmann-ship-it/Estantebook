package com.estante.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.estante.app.data.Book
import com.estante.app.data.BookGroup
import com.estante.app.data.BookRepository

/**
 * Criar ou editar um grupo personalizado: dá um nome e toca nas capas para escolher
 * quais livros fazem parte (por tema, série, ou qualquer critério do usuário).
 * [group] nulo = grupo novo.
 */
@Composable
fun GroupEditorScreen(
    group: BookGroup?,
    books: List<Book>,
    repo: BookRepository,
    onCancel: () -> Unit,
    onSave: (name: String, bookIds: List<String>) -> Unit,
    onDelete: (() -> Unit)?,
) {
    val scheme = MaterialTheme.colorScheme
    var name by rememberSaveable(group?.id) { mutableStateOf(group?.name ?: "") }
    val selected = remember(group?.id) {
        mutableStateListOf<String>().apply { group?.bookIds?.let { addAll(it) } }
    }
    var confirmDelete by rememberSaveable { mutableStateOf(false) }
    BackHandler(onBack = onCancel)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(scheme.background),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 4.dp, top = 6.dp, end = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onCancel) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Voltar",
                    tint = scheme.onSurfaceVariant,
                )
            }
            Text(
                text = if (group == null) "Novo grupo" else "Editar grupo",
                color = scheme.onBackground,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
            )
        }

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Nome do grupo") },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = scheme.onBackground,
                unfocusedTextColor = scheme.onBackground,
                focusedBorderColor = Accent,
                unfocusedBorderColor = scheme.outline,
                cursorColor = Accent,
                focusedLabelColor = Accent,
                unfocusedLabelColor = scheme.onSurfaceVariant,
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
        )
        Text(
            text = if (books.isEmpty()) {
                "Importe livros para poder colocá-los em um grupo."
            } else {
                "Toque nos livros para incluir ou tirar do grupo (${selected.size} selecionado(s))"
            },
            color = scheme.onSurfaceVariant,
            fontSize = 13.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(books, key = { it.id }) { book ->
                val isSelected = book.id in selected
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(COVER_RATIO)
                ) {
                    BookCover(
                        book = book,
                        coverFile = repo.coverFileOf(book),
                        modifier = Modifier.fillMaxSize(),
                        onClick = {
                            if (isSelected) selected.remove(book.id) else selected.add(book.id)
                        },
                    )
                    if (isSelected) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .border(3.dp, Accent)
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(5.dp)
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(Accent),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                Icons.Filled.Check,
                                contentDescription = "Selecionado",
                                tint = Color.White,
                                modifier = Modifier.size(15.dp),
                            )
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Button(
                onClick = { onSave(name.trim(), selected.toList()) },
                enabled = name.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White),
            ) {
                Text("Salvar")
            }
            OutlinedButton(onClick = onCancel) {
                Text("Cancelar", color = scheme.onBackground)
            }
            if (onDelete != null) {
                TextButton(onClick = { confirmDelete = true }) {
                    Text("Excluir grupo", color = Accent)
                }
            }
        }
    }

    if (confirmDelete && onDelete != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Excluir grupo?") },
            text = { Text("O grupo \"${group?.name.orEmpty()}\" será apagado. Os livros continuam na estante.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    onDelete()
                }) {
                    Text("Excluir", color = Accent)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) {
                    Text("Cancelar", color = scheme.onBackground)
                }
            },
            containerColor = scheme.surfaceVariant,
            titleContentColor = scheme.onBackground,
            textContentColor = scheme.onSurfaceVariant,
        )
    }
}
