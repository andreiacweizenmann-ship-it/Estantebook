package com.estante.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.fragment.app.FragmentActivity
import com.estante.app.data.AppSettings
import com.estante.app.data.BookImporter
import com.estante.app.data.BookRepository
import com.estante.app.data.CastController
import com.estante.app.data.ThemeMode
import com.estante.app.ui.BookInfoScreen
import com.estante.app.ui.EstanteTheme
import com.estante.app.ui.FolderSetupScreen
import com.estante.app.ui.GroupEditorScreen
import com.estante.app.ui.LibraryScreen
import com.estante.app.ui.LoadingScreen
import com.estante.app.ui.PdfEditorScreen
import com.estante.app.ui.ReaderScreen
import com.estante.app.ui.SettingsScreen
import com.estante.app.ui.SystemBars
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : FragmentActivity() {
    private var activeRepo: BookRepository? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CastController.init(this)
        val settings = AppSettings(applicationContext)
        setContent {
            val dark = when (settings.themeMode) {
                ThemeMode.DARK -> true
                ThemeMode.LIGHT -> false
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
            }
            EstanteTheme(darkTheme = dark) {
                AppRoot(settings = settings, onRepoChanged = { activeRepo = it })
            }
        }
    }

    override fun onStop() {
        // Garante que o progresso de leitura chegue na pasta quando o app sai da tela.
        activeRepo?.flush()
        super.onStop()
    }
}

/** Cuida da pasta de armazenamento: sem pasta escolhida, o app não abre a estante. */
@Composable
private fun AppRoot(settings: AppSettings, onRepoChanged: (BookRepository?) -> Unit) {
    val context = LocalContext.current
    val scheme = MaterialTheme.colorScheme

    var folderUri by remember { mutableStateOf(settings.folderUri) }
    var repo by remember { mutableStateOf<BookRepository?>(null) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var retryKey by remember { mutableIntStateOf(0) }

    val pickFolder = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                )
            }
            settings.folderUri = uri.toString()
            loadError = null
            folderUri = uri.toString()
            retryKey++
        }
    }

    LaunchedEffect(folderUri, retryKey) {
        repo = null
        val saved = folderUri ?: return@LaunchedEffect
        val uri = Uri.parse(saved)
        val granted = context.contentResolver.persistedUriPermissions.any {
            it.uri == uri && it.isReadPermission && it.isWritePermission
        }
        if (!granted) {
            loadError = "O app perdeu o acesso à pasta anterior. Escolha a pasta novamente."
            settings.folderUri = null
            folderUri = null
            return@LaunchedEffect
        }
        try {
            repo = withContext(Dispatchers.IO) {
                BookRepository(context.applicationContext, uri).also { it.load() }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            loadError = "Não foi possível usar esta pasta: ${e.message ?: e.javaClass.simpleName}"
        }
    }
    LaunchedEffect(repo) { onRepoChanged(repo) }

    SystemBars(color = scheme.background, darkIcons = scheme.background.luminance() > 0.5f)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(scheme.background)
    ) {
        val current = repo
        when {
            current != null -> key(current) {
                MainContent(
                    repo = current,
                    settings = settings,
                    onChangeFolder = { pickFolder.launch(null) },
                )
            }

            folderUri == null || loadError != null -> FolderSetupScreen(
                message = loadError,
                onPick = { pickFolder.launch(null) },
            )

            else -> LoadingScreen("Preparando sua estante…")
        }
    }
}

private const val NEW_GROUP = ""

@Composable
private fun MainContent(
    repo: BookRepository,
    settings: AppSettings,
    onChangeFolder: () -> Unit,
) {
    val context = LocalContext.current
    val books by repo.books.collectAsState()
    val groups by repo.groups.collectAsState()
    val scope = rememberCoroutineScope()
    val importer = remember(repo) { BookImporter(context.applicationContext, repo) }
    val startDark = MaterialTheme.colorScheme.background.luminance() < 0.5f

    var infoId by rememberSaveable { mutableStateOf<String?>(null) }
    var readingId by rememberSaveable { mutableStateOf<String?>(null) }
    var settingsOpen by rememberSaveable { mutableStateOf(false) }
    var groupEditorId by rememberSaveable { mutableStateOf<String?>(null) }
    var pdfEditId by rememberSaveable { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf<String?>(null) }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            scope.launch {
                var imported = 0
                val errors = mutableListOf<String>()
                uris.forEachIndexed { index, uri ->
                    status = "Importando ${index + 1} de ${uris.size}…"
                    importer.import(uri)
                        .onSuccess { imported++ }
                        .onFailure { errors.add(it.message ?: "erro desconhecido") }
                }
                status = buildString {
                    if (imported > 0) append("$imported livro(s) importado(s). ")
                    if (errors.isNotEmpty()) append(errors.joinToString(" | "))
                }
                delay(if (errors.isEmpty()) 2500L else 7000L)
                status = null
            }
        }
    }

    val reading = books.find { it.id == readingId }
    val info = books.find { it.id == infoId }
    val editorId = groupEditorId
    val pdfEditing = books.find { it.id == pdfEditId }

    when {
        reading != null -> ReaderScreen(
            book = reading,
            repo = repo,
            startDark = startDark,
            onClose = {
                readingId = null
                repo.flush()
            },
        )

        settingsOpen -> SettingsScreen(
            themeMode = settings.themeMode,
            onThemeChange = { settings.updateTheme(it) },
            folderName = repo.folderName,
            bookCount = books.size,
            onChangeFolder = onChangeFolder,
            onBack = { settingsOpen = false },
        )

        editorId != null -> {
            val editing = groups.find { it.id == editorId }
            GroupEditorScreen(
                group = editing,
                books = books,
                repo = repo,
                onCancel = { groupEditorId = null },
                onSave = { name, ids ->
                    if (editing == null) {
                        repo.createGroup(name, ids)
                    } else {
                        repo.updateGroup(editing.id, name, ids)
                    }
                    groupEditorId = null
                },
                onDelete = editing?.let { group ->
                    {
                        repo.deleteGroup(group.id)
                        groupEditorId = null
                    }
                },
            )
        }

        pdfEditing != null -> key(pdfEditing.id) {
            PdfEditorScreen(
                book = pdfEditing,
                repo = repo,
                onClose = { pdfEditId = null },
            )
        }

        info != null -> BookInfoScreen(
            book = info,
            coverFile = repo.coverFileOf(info),
            groups = groups,
            onBack = { infoId = null },
            onRead = { readingId = info.id },
            onSave = { updated -> repo.update(updated.id) { updated } },
            onDelete = {
                repo.delete(info.id)
                infoId = null
            },
            onToggleGroup = { groupId -> repo.toggleBookInGroup(groupId, info.id) },
            onEditPdf = { pdfEditId = info.id },
        )

        else -> LibraryScreen(
            books = books,
            groups = groups,
            repo = repo,
            status = status,
            onOpen = { readingId = it.id },
            onInfo = { infoId = it.id },
            onImport = { importLauncher.launch(arrayOf("*/*")) },
            onOpenSettings = { settingsOpen = true },
            onNewGroup = { groupEditorId = NEW_GROUP },
            onEditGroup = { groupEditorId = it },
        )
    }
}
