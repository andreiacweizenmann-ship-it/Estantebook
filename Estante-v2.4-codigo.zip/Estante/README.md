# Estante — leitor de livros para Android

Aplicativo estilo Kindle, feito em Kotlin + Jetpack Compose, que lê **PDF, CBR, CBZ e EPUB** e transforma cada arquivo em um livro na sua estante.

## O que ele faz

- **Pasta de armazenamento obrigatória**: na primeira abertura o app pede para você escolher uma pasta do aparelho. Livros, capas, grupos e progresso de leitura ficam nela (`estante.json`, `livros/`, `capas/`). Dá para trocar a pasta em *Configurações*. Se você já usava a versão 1.0, seus livros são levados para a pasta automaticamente.
- **Estante em carrosséis**: cada prateleira (*Continuar lendo*, seus grupos e *Todos os livros*) é um carrossel; com muitos livros, é só arrastar para o lado. *Todos os livros* usa duas fileiras.
- **Grupos personalizados**: ícone de pasta com "+" no topo da estante. Dê um nome e toque nas capas para escolher os livros (por tema, série, ou o critério que quiser). O lápis ao lado do nome do grupo edita ou exclui. Na tela de informações do livro, o botão **Grupos** inclui ou tira o livro de qualquer grupo.
- **Configurações** (engrenagem no topo): tema **Escuro**, **Claro** ou **Automático**, pasta de armazenamento e créditos.
- **Botão "+" (cor de destaque índigo)**: abre o seletor de arquivos do celular e importa um ou vários livros de uma vez.
- **Busca** por título, autor, coleção ou estúdio, inclusive **por voz** (ícone do microfone).
- **Segurar a capa** abre a tela de informações: capa, nome, autor, coleção, estúdio, estrelas e andamento.
- **Editar**: nome, autor, coleção, estúdio, avaliação com estrelas, marcar como lido e excluir livro.
- **Capas maiores e sem corte**: a imagem da capa aparece inteira.
- **Leitura**: deslizar para virar a página, zoom com dois dedos (ou toque duplo), toque nas bordas para avançar/voltar e **retoma da última página lida**.
  - Um selo no rodapé mostra sempre **página atual / total** e a **porcentagem lida**.
  - Tocando no centro da tela aparece a **barra de navegação rápida** entre páginas, junto com a porcentagem e o total (ex.: 20 / 200).
- **Editar PDF** (botão na tela de informações de um PDF): abre um editor com as miniaturas de todas as páginas.
  - **Juntar PDF**: escolhe outro PDF e acrescenta as páginas dele (depois da página selecionada, ou no fim). O texto e o tamanho das páginas são mantidos.
  - **Adicionar imagens**: cada foto ou imagem vira uma página (a orientação das fotos do celular é respeitada).
  - **Excluir página**, **mover** para trás/frente e **Remover imagens da página** (tira as figuras que estão desenhadas na página, mantendo o texto).
  - **Melhorar qualidade**: por página ou em todas. Amplia imagens pequenas, estica o contraste automaticamente e aumenta a nitidez, com intensidade Leve, Normal ou Forte. O botão **Prévia da melhoria** mostra a página grande, com chave para comparar com o original.
  - **Salvar** como novo livro (o original fica intacto) ou **substituir o original** (mantém avaliação e grupos).
  - Páginas melhoradas viram imagem de alta resolução (o texto delas deixa de ser selecionável); as demais são copiadas sem perda.
- **Chromecast**: ícone de transmitir na estante e na leitura (PDF e quadrinhos). Conecte em uma TV com Chromecast/Google TV, a mesma rede Wi-Fi do celular, e as páginas aparecem na TV em 1920x1080, com fundo desfocado nas laterais. Vire a página no celular e a TV acompanha. EPUB ainda não é transmitido.
- Modo **mangá** (leitura da direita para a esquerda) nos quadrinhos.
- **CBR** é convertido em CBZ na importação, então a leitura fica rápida. Se o quadrinho tiver `ComicInfo.xml`, título, autor, coleção e estúdio são preenchidos sozinhos.
- **EPUB** em páginas, com botões A− / A+ para o tamanho da letra e tema claro/escuro. A barra, a porcentagem e o total de páginas valem para o livro inteiro (o total é uma **estimativa**, por isso aparece como "~200", e muda um pouco com o tamanho da letra).

## Como gerar o APK sem instalar nada (GitHub)

Precisa de um computador com navegador e uma conta gratuita no GitHub.

1. Descompacte este projeto.
2. Em github.com, crie um repositório novo (pode ser privado).
3. Clique em **uploading an existing file** e arraste **todo o conteúdo** da pasta, incluindo as pastas `.github`, `gradle` e `app`.
   - A pasta `.github` é oculta. No Windows, ative "Itens ocultos" no Explorador; no Mac, use Cmd + Shift + ponto.
4. Clique em **Commit changes**.
5. Abra a aba **Actions**. O fluxo **Gerar APK** começa sozinho (leva de 5 a 10 minutos). Se não começar, clique nele e em **Run workflow**.
6. Quando ficar verde, abra a execução e baixe **Estante-APK** em *Artifacts*. Dentro do zip está o `app-debug.apk`.
7. Passe o arquivo para o celular e instale (o Android vai pedir para permitir instalar de fontes desconhecidas).

Se o fluxo falhar, abra a execução, copie a mensagem de erro e envie para quem está te ajudando.

## Como gerar com o Android Studio (opcional)

Abra a pasta no Android Studio, aguarde a sincronização e use **Build > Build APK(s)**.

## Limitações conhecidas

- O Android não deixa escolher a raiz do armazenamento nem a pasta *Download* como pasta do app; crie uma pasta nova (ex.: "Estante").
- Para ler, o livro é copiado da pasta para um espaço temporário do app (os 4 mais recentes ficam guardados). Pastas em nuvem (Google Drive etc.) podem ser lentas; prefira uma pasta do próprio aparelho.
- Se o mesmo `estante.json` for usado em dois aparelhos ao mesmo tempo, vale a última gravação.
- CBR no formato **RAR 5** não é suportado pela biblioteca usada; converta para CBZ.
- No EPUB não há zoom por pinça nem seleção de texto (o tamanho da letra é ajustado pelos botões A− / A+).
- PDFs protegidos por senha não são abertos.
- Em *Remover imagens da página*, figuras dentro de blocos aninhados do PDF (formulários) não são removidas.
- O código foi escrito sem poder compilar nem testar em um aparelho, então podem aparecer pequenos erros na primeira compilação.
